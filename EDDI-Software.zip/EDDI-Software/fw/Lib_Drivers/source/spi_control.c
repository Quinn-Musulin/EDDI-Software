/*!
 * @file
 * @brief     Driver for the NXP 74HC595PW Shift Register
 * @ingroup   IP_SPI
 *
 * @copyright Copyright 2013 Embedded Artists AB
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation is hereby granted, without fee, provided that it
 * is used in conjunction with NXP Semiconductors microcontrollers.  This
 * copyright, permission, and disclaimer notice must appear in all copies of
 * this code.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */


/******************************************************************************
 * Includes
 *****************************************************************************/

#include <string.h>
#include <stdio.h>
#include "lpc_types.h"
#include "lpc43xx_ssp.h"
#include "lpc43xx_timer.h"
#include "spi_control.h"

/******************************************************************************
 * Defines and typedefs
 *****************************************************************************/

/*! Chip Select On. GPIO is used instead of the SSP_SSEL. */
//#define CS_ON    (LPC_GPIO_PORT->CLR[3] |= (1UL << 7)) // p6.11 (gpio3[7]) -> low
#define CS_HIGH     (LPC_GPIO_PORT->SET[0] |= (1UL << 15)) // CS set high on GPIO0_15 (SSP1_SEL on Link2 schematic)


/*! Chip Select Off. GPIO is used instead of the SSP_SSEL. */
//#define CS_OFF   (LPC_GPIO_PORT->SET[3] |= (1UL << 7)) // p6.11 (gpio3[7]) -> high
#define CS_LOW      (LPC_GPIO_PORT->CLR[0] |= (1UL << 15)) // CS set low on GPIO0_15 (SSP1_SEL on Link2 schematic)

/*! SPI bus to use */
#define SSP_PORT  (LPC_SSP1)

/*! Clock rate to use */
#define SSP_CLOCK 3000000
#define SSP_CLOCK_LOW 100000


/* MMC/SD command */
//#define CMD0	(0)			/* GO_IDLE_STATE */
#define CMD1	(1)			/* SEND_OP_COND (MMC) */
//#define	ACMD41	(0x80+41)	/* SEND_OP_COND (SDC) */
//#define CMD8	(8)			/* SEND_IF_COND */
#define CMD9	(9)			/* SEND_CSD */
#define CMD10	(10)		/* SEND_CID */
#define CMD12	(12)		/* STOP_TRANSMISSION */
#define ACMD13	(0x80+13)	/* SD_STATUS (SDC) */
#define CMD16	(16)		/* SET_BLOCKLEN */
//#define CMD17	(17)		/* READ_SINGLE_BLOCK */
#define CMD18	(18)		/* READ_MULTIPLE_BLOCK */
#define CMD23	(23)		/* SET_BLOCK_COUNT (MMC) */
#define	ACMD23	(0x80+23)	/* SET_WR_BLK_ERASE_COUNT (SDC) */
//#define CMD24	(24)		/* WRITE_BLOCK */
#define CMD25	(25)		/* WRITE_MULTIPLE_BLOCK */
#define CMD32	(32)		/* ERASE_ER_BLK_START */
#define CMD33	(33)		/* ERASE_ER_BLK_END */
#define CMD38	(38)		/* ERASE */
#define	CMD48	(48)		/* READ_EXTR_SINGLE */
#define	CMD49	(49)		/* WRITE_EXTR_SINGLE */
//#define CMD55	(55)		/* APP_CMD */
//#define CMD58	(58)		/* READ_OCR */

#define CMD0        0
#define CMD0_ARG    0x00000000
#define CMD0_CRC    0x94

#define CMD8        8
#define CMD8_ARG    0x0000001AA
#define CMD8_CRC    0x86 //(1000011 << 1)

#define CMD58       58
#define CMD58_ARG   0x00000000
#define CMD58_CRC   0x00

#define CMD55       55
#define CMD55_ARG   0x00000000
#define CMD55_CRC   0x00

#define ACMD41      41
#define ACMD41_ARG  0x40000000
#define ACMD41_CRC  0x00

#define CMD17                   17
#define CMD17_CRC               0x00
#define SD_MAX_READ_ATTEMPTS    1563

#define CMD24                   24
#define CMD24_ARG               0x00
#define SD_MAX_WRITE_ATTEMPTS   3907
#define CMD24_CRC           0x00


/******************************************************************************
 * External global variables
 *****************************************************************************/

/******************************************************************************
 * Local variables
 *****************************************************************************/

static SSP_CFG_Type SSP_ConfigStruct;

static uint8_t currentValue = DEFAULT_VALUES;

/******************************************************************************
 * Local Functions
 *****************************************************************************/


/******************************************************************************
 * Public Functions
 *****************************************************************************/

/**************************************************************************//**
 *
 * @brief Initialize the Shift Registry Driver
 *
 *****************************************************************************/
void spi_control_init(void)
{
  // Initialize SSP configuration structure to default
  SSP_ConfigStructInit(&SSP_ConfigStruct);

  // Set clock rate and number of address bits
  SSP_ConfigStruct.ClockRate = 1000000;
  //SSP_ConfigStruct.Databit = SSP_DATABIT_8;

  // Initialize SSP peripheral with parameter given in structure above
  SSP_Init(SSP_PORT, &SSP_ConfigStruct);

  // Enable SSP peripheral
  SSP_Cmd(SSP_PORT, ENABLE);

  spi_control_write(DEFAULT_VALUES, 0xff);
}

/**************************************************************************//**
 *
 * @brief Write to the Shift Register
 *
 * Blocks until data has been transferred.
 *
 * @param [in] data    Data to write
 * @param [in] mask    A bit value of 1 sets the value, 0 is ignored
 *
 *****************************************************************************/
void spi_control_write(uint8_t data, uint8_t mask)
{
  uint8_t newVal;
  SSP_DATA_SETUP_Type sspCfg;

  newVal = currentValue & ~mask;
  newVal |= (data & mask);
  if (newVal == currentValue) {
    // nothing to do
    return;
  }
  currentValue = newVal;

  //CS_ON;

  sspCfg.tx_data = &newVal;
  sspCfg.rx_data = NULL;
  sspCfg.length  = 1;

  SSP_ReadWrite(SSP_PORT, &sspCfg, SSP_TRANSFER_POLLING);

  //CS_OFF;
}



/**************************************************************************//**
 *
 * @brief Command function for SD card
 *
 *****************************************************************************/


void SD_command(uint8_t cmd, uint32_t arg, uint8_t crc)
{
    // transmit command to sd card
	SSP_SendData(LPC_SSP1,cmd|0x40);

    // transmit argument
	SSP_SendData(LPC_SSP1,(uint8_t)(arg >> 24));
	SSP_SendData(LPC_SSP1,(uint8_t)(arg >> 16));
	SSP_SendData(LPC_SSP1,(uint8_t)(arg >> 8));
	SSP_SendData(LPC_SSP1,(uint8_t)(arg));

    // transmit crc
	SSP_SendData(LPC_SSP1,crc|0x01);
}

/**************************************************************************//**
 *
 * @brief Read response R1
 *
 *****************************************************************************/

uint8_t SD_readRes1()
{
    uint8_t i = 0, res1;

    // keep polling until actual data received
    while((res1 = SSP_ReceiveData(LPC_SSP1)) == 0xFF)
    {
        i++;

        // if no data received for 8 bytes, break
        if(i > 20) break;
    }

    return res1;
}


/**************************************************************************//**
 *
 * @brief Read response R7
 *
 *****************************************************************************/


void SD_readRes7(uint8_t *res)
{
    // read response 1 in R7
    res[0] = SD_readRes1();

    // if error reading R1, return
    if(res[0] > 1) return;

    // read remaining bytes
    res[1] = SPI_transfer(0xFF);
    res[2] = SPI_transfer(0xFF);
    res[3] = SPI_transfer(0xFF);
    res[4] = SPI_transfer(0xFF);
}


/**************************************************************************//**
 *
 * @brief Init for SD card
 *
 *****************************************************************************/

uint8_t spi_SD_init(LPC_SSPn_Type *SSPx)
{

	uint8_t flag1=0,flag2=0;
	uint8_t i=0,i2=0,i3=0,f=0,R1=1;
	uint16_t j=0;
	uint16_t delay_time_us=100;

	uint8_t buffR1[20];
	uint8_t buffR2[20];
	uint8_t clock[20] = {0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff};
	uint8_t receiving[5] = {0xff,0xff,0xff,0xff,0xff};

	SSP_DATA_SETUP_Type SSP_SD_init1;
	SSP_SD_init1.tx_data = clock;
	SSP_SD_init1.length = 20;
	SSP_SD_init1.rx_data = buffR1;

	SSP_DATA_SETUP_Type SSP_SD_init2;
	SSP_SD_init2.tx_data = clock;
	SSP_SD_init2.length = 20;
	SSP_SD_init2.rx_data = buffR2;
	int delay=1000000;
	uint8_t res1=0, k=0;


	while (flag1==0)
	{

		SD_Card_Power_On();
		//zero buffR1
		for(int i=0;i<20;i++)
		{
			buffR1[i]=0;
		}

		flag2=0;

		// step 1. send some clock cycles

		CS_HIGH;

		//give some time to power up
		TIM_Waitus(delay_time_us);

		for (i=0; i<0x0F; i++)
		{
			SSP_SendData(LPC_SSP1,0xff);          // send 72 clocks
		}

		TIM_Waitus(delay_time_us);

		CS_HIGH;

		SSP_SendData(LPC_SSP1,0xff);

		// step 2. Write a CM0 (0) with CS low to reset the SD card.
		// There should be an R1 response to this.

		SSP_SendData(LPC_SSP1,0xff);
		CS_LOW; // 'on'
		SSP_SendData(LPC_SSP1,0xff);

		TIM_Waitus(delay_time_us);

		// send CMD0
		SD_command(CMD0, CMD0_ARG, CMD0_CRC);

		SSP_ReadWrite(LPC_SSP1,&SSP_SD_init1,SSP_TRANSFER_POLLING);   // send 20 clocks
		//res1 = SD_readRes1();

		TIM_Waitus(delay_time_us);

		SSP_SendData(LPC_SSP1,0xff);
		CS_HIGH;
		SSP_SendData(LPC_SSP1,0xff);

		i=0;

		while(flag2==0)
		{
			if (buffR1[i]==1)
			{
				flag1=1;
				flag2=1;
				break;
			}
			if (i==19)
			{
				flag2=1;
				SD_Card_Power_Off();

				TIM_Waitus(delay_time_us);

			}
			i++;
		}
	}

	// send CMD8
	SSP_SendData(LPC_SSP1,0xff);
	CS_LOW;
	SSP_SendData(LPC_SSP1,0xff);

	SD_command(CMD8, CMD8_ARG, CMD8_CRC);

	SSP_ReadWrite(LPC_SSP1,&SSP_SD_init2,SSP_TRANSFER_POLLING);   // send 20 clocks

	SSP_SendData(LPC_SSP1,0xff);
	CS_HIGH;
	SSP_SendData(LPC_SSP1,0xff);

	i=0;
	while(buffR2[i]==255)
	{
		i++;
		if (i==20)
		{
			buffR2[i] == 200; // break the while loop
			return 92;
			//printf("Step 2. Timeout Error \n");

		}
	}

	// checking received bits
	for(f=i;f<(i+5);f++)
	{
		//printf("%d \n",buffR2[f]);
		if (f == i)
		{
			if (!(buffR2[f]==1))
			{

				//printf("Step 2. Byte 1 (R1) Error \n");
				//printf("%d \n",buffR2[f]);
				return 2;
			}
		}

		if (f == (i+1))
		{
			if (!(buffR2[f]==0))
			{

				//printf("Step 2. Byte 2 Error \n");
				//printf("%d \n",buffR2[f]);
				return 2;
			}
		}

		if (f == (i+2))
		{
			if (!(buffR2[f]==0))
			{

				//printf("Step 2. Byte 3 Error \n");
				//printf("%d \n",buffR2[f]);
				return 2;
			}
		}

		if (f == (i+3))
		{
			if (!(buffR2[f]==1))
			{

				//printf("Step 2. Byte 4 Error \n");
				//printf("%d \n",buffR2[f]);
				return 2;
			}
		}

		if (f == (i+4))
		{
			if (!(buffR2[f]==170))
			{

				//printf("Step 2. Byte 5 Error \n");
				//printf("%d \n",buffR2[f]);
				return 2;
			}
		}




	}


	// send CMD58
	SSP_SendData(LPC_SSP1,0xff);
	CS_LOW;
	SSP_SendData(LPC_SSP1,0xff);

	SD_command(CMD58, CMD58_ARG, CMD58_CRC);

	SSP_ReadWrite(LPC_SSP1,&SSP_SD_init2,SSP_TRANSFER_POLLING);   // send 20 clocks

	SSP_SendData(LPC_SSP1,0xff);
	CS_HIGH;
	SSP_SendData(LPC_SSP1,0xff);

	i=0;
	while(buffR2[i]==255)
	{
		i++;
		if (i==20)
		{
			buffR2[i] == 200; // break the while loop
			return 93;
			//printf("Step 2. Timeout Error \n");
		}
	}

	// checking if 3.3V supported
	for(f=i;f<(i+5);f++)
	{
		//printf("%d \n",buffR2[f]);
		if (f == (i+2))
		{
			if (!(buffR2[f] & 0x30))
			{
				return 3;
				//printf("Step 3. 3.3 V not supported \n");
				//printf("%d \n",buffR2[f]);
			}
		}
	}



	// SEND FINAL COMMANDS (CMD55 + ACMD41) UNTIL WE GET R1 = 0.

	i2=0;
	while(R1==1)
	{

		// send CMD55
		SSP_SendData(LPC_SSP1,0xff);
		CS_LOW;
		SSP_SendData(LPC_SSP1,0xff);

		SD_command(CMD55, CMD55_ARG, CMD55_CRC);

		SSP_ReadWrite(LPC_SSP1,&SSP_SD_init2,SSP_TRANSFER_POLLING);   // send 20 clocks

		SSP_SendData(LPC_SSP1,0xff);
		CS_HIGH;
		SSP_SendData(LPC_SSP1,0xff);

		// send ACMD41
		SSP_SendData(LPC_SSP1,0xff);
		CS_LOW;
		SSP_SendData(LPC_SSP1,0xff);

		SD_command(ACMD41, ACMD41_ARG, ACMD41_CRC);

		SSP_ReadWrite(LPC_SSP1,&SSP_SD_init2,SSP_TRANSFER_POLLING);   // send 20 clocks

		SSP_SendData(LPC_SSP1,0xff);
		CS_HIGH;
		SSP_SendData(LPC_SSP1,0xff);


		i=0;

		while(buffR2[i]==255)
		{
			i++;
		}

		R1 = buffR2[i];

		i2++;

		if (i2 == 50)
		{
			//R1=0; // break the while loop
			return 94;
			//printf("CMD55 + ACMD41 Timeout Error \n");
		}

	}



	i2=1;
	i3=0;

	while(i2==1)
	{

		// send CMD58 until SD card ready
		SSP_SendData(LPC_SSP1,0xff);
		CS_LOW;
		SSP_SendData(LPC_SSP1,0xff);

		SD_command(CMD58, CMD58_ARG, CMD58_CRC);

		SSP_ReadWrite(LPC_SSP1,&SSP_SD_init2,SSP_TRANSFER_POLLING);   // send 20 clocks

		SSP_SendData(LPC_SSP1,0xff);
		CS_HIGH;
		SSP_SendData(LPC_SSP1,0xff);

		i=0;

		while(buffR2[i]==255)
		{
			i++;
		}

		for(f=i;f<(i+5);f++)
		{

			if (f == (i+1))
			{
				if (!(buffR2[f] & 0x80))
				{
					//printf("Card Power Up Busy \n");
					//printf("%d \n",buffR2[f]);
					i2=1;

					if (i3 == 50)
					{
						return 95;
					}

					i3++;

					for(int j=0;j<1000;j++)
					{
						//wait
					}

				}
				else
				{
					//printf("SD Card Initialization Complete \n");
					i2=0;
				}
			}
		}
	}
	return 5;
}


/**************************************************************************//**
 *
 * @brief Read Single Block
 *
 *****************************************************************************/


uint8_t SD_readSingleBlock(uint32_t addr, uint8_t *buf, uint8_t *token, LPC_SSPn_Type *SSPx)
{

	uint8_t flag=0,flag2=0;
    uint16_t i=0,i2=0,k=0,counter_read=0;
	uint8_t one_clock[1] = {0xff};
	uint8_t READ_RESPONSE[1]={255};
	uint8_t READ_RESPONSE2[1];
	uint8_t READ_RESPONSE3[20];
	uint8_t READ_RESPONSE4[512];
	uint8_t READ_CRC_SEND[2] = {0xff,0xff};
	uint8_t READ_CRC[2];
	uint8_t receive_clock[20] = {0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff};

	flag=0;

	SSP_DATA_SETUP_Type SSP_SD_init_SD_READ;
	SSP_SD_init_SD_READ.tx_data = one_clock;
	SSP_SD_init_SD_READ.length = 1;
	SSP_SD_init_SD_READ.rx_data = READ_RESPONSE2;

	SSP_DATA_SETUP_Type SSP_SD_init_SD_READ2;
	SSP_SD_init_SD_READ2.tx_data = one_clock;
	SSP_SD_init_SD_READ2.length = 1;
	SSP_SD_init_SD_READ2.rx_data = READ_RESPONSE2;

	SSP_DATA_SETUP_Type SSP_SD_init_SD_READ_CRC;
	SSP_SD_init_SD_READ_CRC.tx_data = READ_CRC_SEND;
	SSP_SD_init_SD_READ_CRC.length = 2;
	SSP_SD_init_SD_READ_CRC.rx_data = READ_CRC;

    // set token to none
    *token = 0xFF;



   // while(flag==0)
    //{

    	i=0;
    	flag2=0;
    	i2=0;

    	while(counter_read<100)
    	{

    		// assert chip select
		SSP_SendData(LPC_SSP1,0xFF);
	    CS_LOW;
	    SSP_SendData(LPC_SSP1,0xFF);

	    // send CMD17
	    SD_command(CMD17, addr, CMD17_CRC);

    	while(i2 != 0xfe && k<20000)
    	{
    	    SSP_ReadWrite(LPC_SSP1,&SSP_SD_init_SD_READ,SSP_TRANSFER_POLLING); // reading for when we get 0xfe
    	    i2=READ_RESPONSE2[0];
    	    k++;
    	}

    	if (i2==0xfe)
    	{

    		 for (int p=0;p<512;p++) // reading from the card
    		    {
    		        SSP_ReadWrite(LPC_SSP1,&SSP_SD_init_SD_READ2,SSP_TRANSFER_POLLING);
    		        buf[p]=	READ_RESPONSE2[0];
    		    }

    		    SSP_ReadWrite(LPC_SSP1,&SSP_SD_init_SD_READ_CRC,SSP_TRANSFER_POLLING);


    		    SSP_SendData(LPC_SSP1,0xff);
    		    CS_HIGH;
    		    SSP_SendData(LPC_SSP1,0xff);

    		    //printf("Read Complete \n");

    		    return 15;

    	}

    	counter_read++;
    	k=0;

		//de assert chip select
		SSP_SendData(LPC_SSP1,0xFF);
		CS_HIGH;
		SSP_SendData(LPC_SSP1,0xFF);


    	if (counter_read == 100)
        	{

        		//printf("Read Timeout 1 \n");
        		return 9;
        	}
    	}


    	//while(flag2==0) // checking for the correct response. If not there send command and check again.
    	//{
    		//if (READ_RESPONSE3[i] == 0xfe)
    		//{
    			//flag=1;
    			//flag2=1;
    		//}
    		//if (i==19)
    		//{
    		//flag2=1;
    		//}
    		//i++;
    	//}

    	//if (i2 == 50000) // max is ~65.536k
    	//{
    	//	printf("Read Timeout 1 \n");
    	//	return 9;
    	//}

    	//i2++;



    //*token = READ_RESPONSE3[i-1];

    //printf("Card Ready for Read? ... %d \n",READ_RESPONSE3[i-1]);


    //SSP_ReadWrite(LPC_SSP1,&SSP_SD_init_SD_READ2,SSP_TRANSFER_POLLING);

    //for (int p=0;p<512;p++) // reading from the card
   // {
    //    SSP_ReadWrite(LPC_SSP1,&SSP_SD_init_SD_READ2,SSP_TRANSFER_POLLING);
    //    buf[p]=	READ_RESPONSE2[0];
    //}

    //SSP_ReadWrite(LPC_SSP1,&SSP_SD_init_SD_READ_CRC,SSP_TRANSFER_POLLING);


   //SSP_SendData(LPC_SSP1,0xff);
    //CS_HIGH;
    //SSP_SendData(LPC_SSP1,0xff);

    //printf("Read Complete \n");

    //return 15;

}

/**************************************************************************//**
 *
 * @brief Write Single Block
 *
 *****************************************************************************/

uint8_t SD_writeSingleBlock(uint32_t addr, uint8_t *buf, uint8_t *token,LPC_SSPn_Type *SSPx)
{

	uint8_t flag=0,flag2=0,flag3=0,flag4=0;
	uint8_t SEND_CLOCKS[512];
	uint8_t receive_clock[20] = {0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff};
	uint8_t readAttempts, read;
	uint8_t one_clock[1] = {0xff};
	uint8_t READ_RESPONSE[20];
	uint8_t i=0,i2=0;
	int delay=0;

	SSP_DATA_SETUP_Type SSP_SD_init_SD_READ5;
	SSP_SD_init_SD_READ5.tx_data = receive_clock;
	SSP_SD_init_SD_READ5.length = 20;
	SSP_SD_init_SD_READ5.rx_data = READ_RESPONSE;

    // set token to none
    *token = 0xFF;


    while (flag2==0)
    {
    	flag=0;
    	flag2=0;
    	flag3=0;
    	flag4=0;

    	while (flag==0)
    	{

    		// assert chip select
    		SSP_SendData(LPC_SSP1,0xFF);
    		CS_LOW;
    		SSP_SendData(LPC_SSP1,0xFF);


    		// send CMD24
    		SD_command(CMD24, addr, CMD24_CRC);

    		SSP_ReadWrite(LPC_SSP1,&SSP_SD_init_SD_READ5,SSP_TRANSFER_POLLING); // reading to get R1 = 0

    		i=0;

    		flag4=0;

    		while(flag4==0)
    		{
    			//printf("%d \n",READ_RESPONSE[i]);

    			if(READ_RESPONSE[i]==0)
    			{
    				flag4=1;
    				flag=1;
    			}

    			if (i==19)
    			{
    				flag4=1; // break the while loop
    				//printf("Writing Timeout Error 1\n");
    				//LPC_GPIO_PORT->SET[5] |= (1UL << 9); // red
    				return 9; // timeout

    				// de-assert chip select
    				SSP_SendData(LPC_SSP1,0xFF);
    				CS_HIGH;
    				SSP_SendData(LPC_SSP1,0xFF);
    			}
    			i++;
    		}

    		if (i2>=200)
    		{

    			//printf("Writing Timeout Error 2\n");
    			//LPC_GPIO_PORT->SET[5] |= (1UL << 9); // red
    			return 9; // timeout
    			//i2=0;
    			//flag=1;
    			//flag3=1;
    			//flag4=1;
    		}

    		i2++;

    	}

    	// send start token
    	SSP_SendData(LPC_SSP1,0xFE);

    	// write buffer to card
    	for(uint16_t i = 0; i < 512; i++) {SSP_SendData(LPC_SSP1,buf[i]);}


    	SSP_ReadWrite(LPC_SSP1,&SSP_SD_init_SD_READ5,SSP_TRANSFER_POLLING); // reading for when we get 0xfe

    	i=0;

    	//(READ_RESPONSE[i]==255)

    	while(flag3==0)
    	{

    		if ((READ_RESPONSE[i] & 0x1f)==0x05)
    		{
    			flag2=1;
    			flag3=1;
    			//printf("Write Accepted \n");
    			TIM_Waitus(100);
    		}


    		if (i==19)
    		{
    			//printf("Writing Timeout Error 3\n");
    			return 9;
    			flag3=1;
    			flag2=1;
    			flag=1;

				// de-assert chip select
				SSP_SendData(LPC_SSP1,0xFF);
				CS_HIGH;
				SSP_SendData(LPC_SSP1,0xFF);

    		}
    		i++;
    	}

    }

    // set token to data accepted
    *token = 0x05;

    // de-assert CS
    SSP_SendData(LPC_SSP1,0xff);
    CS_HIGH;
    SSP_SendData(LPC_SSP1,0xff);

    return 12;
}

