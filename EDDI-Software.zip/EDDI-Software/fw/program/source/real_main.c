/*!
 * @file
 * @brief   Program entry point
 *
 * @copyright Copyright 2013 Embedded Artists AB
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation is hereby granted, without fee, provided that it
 * is used in conjunction with NXP Semiconductors microcontrollers.  This
 * copyright, permission, and disclaimer notice must appear in all copies of
 * this code.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */


/******************************************************************************
 * Includes
 *****************************************************************************/

#ifdef __CODE_RED
#include <cr_section_macros.h>
#endif

#include "lpc_types.h"
#include "lpc43xx_adc.h"
#include "lpc43xx_cgu_improved.h"
#include "lpc43xx_i2c.h"
#include "lpc43xx_rgu.h"
#include "lpc43xx_scu.h"
#include "lpc43xx_timer.h"
#include "lpc43xx_uart.h"

#include "debug_frmwrk.h"

#include "spi_control.h"
#include "led.h"
#include "log.h"
#include "usb_handler.h"

#include "capture.h"
#include "generator.h"
#include "labtool_config.h"
#include "statemachine.h"
#include "experiments.h"

#include "capture_vadc.h"
#include <stdint.h>
#include "stdlib.h"
#include "arm_math.h"
#include "math.h"
#include "arm_common_tables.h"

#include <stdbool.h>

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

#include "ff.h"
#include "ffconf.h"
#include "diskio.h"
#include <cr_section_macros.h>


/******************************************************************************
 * Typedefs and defines
 *****************************************************************************/


/*!
 * I2C bus to use.
 */
#define I2C_PORT (LPC_I2C0)
//#define UART_PORT (LPC_UART2)

/*! \name SCU settings for the pins
 * \{
 */
#define SETTINGS_GPIO_IN    (PUP_DISABLE | PDN_DISABLE | SLEWRATE_SLOW | INBUF_ENABLE  | FILTER_ENABLE)
#define SETTINGS_GPIO_IN2   (PUP_DISABLE | PDN_ENABLE | SLEWRATE_SLOW | INBUF_ENABLE  | FILTER_ENABLE)
#define SETTINGS_GPIO_IN3   (PUP_ENABLE | PDN_DISABLE | SLEWRATE_SLOW | INBUF_ENABLE  | FILTER_ENABLE)
#define SETTINGS_GPIO_OUT   (PUP_DISABLE | PDN_DISABLE | SLEWRATE_SLOW |                 FILTER_ENABLE)
#define SETTINGS_SGPIO      (PDN_DISABLE | PUP_DISABLE |                 INBUF_ENABLE                 )
#define SETTINGS_SPIFI      (PUP_DISABLE | PDN_DISABLE | SLEWRATE_SLOW | INBUF_ENABLE  | FILTER_ENABLE)
#define SETTINGS_SSP        (PUP_DISABLE | PDN_DISABLE | SLEWRATE_SLOW | INBUF_ENABLE  | FILTER_ENABLE)
#define SETTINGS_SSP2        (PUP_ENABLE | PDN_DISABLE | SLEWRATE_SLOW | INBUF_ENABLE  | FILTER_ENABLE)
#define SETTINGS_GPIO_OUT2   (0x1 << 3 | 0x1 << 4)
/* \} */

/******************************************************************************
 * Local variables
 *****************************************************************************/

volatile uint32_t mstick = 0;


/******************************************************************************
 * Global variables
 *****************************************************************************/

typedef struct
{
  uint32_t         numEnabledSGPIO; /*!< Number of enabled digital signals */
  uint32_t         numEnabledVADC;  /*!< Number of enabled analog signals */
  uint32_t         sampleRate;      /*!< Wanted sample rate */

  /*! Post fill configuration. The lower 8 bits specify the percent of the
   * maximum buffer size that will be used for samples taken AFTER the trigger.
   * The upper 24 bits specifies the maximum number of samples to gather after
   * a trigger has been found.*/
  uint32_t         postFill;

  // cap_sgpio_cfg_t  sgpio;  /*!< Configuration of digital signals */
  cap_vadc_cfg_t   vadc;   /*!< Configuration of analog signals */
} capture_cfg_t;

//TAKE THIS OUT IF SD CARD NO LONGER WORKS

/** @brief SSP configuration structure */
typedef struct {
	uint32_t Databit; 		/** Databit number, should be SSP_DATABIT_x,
							where x is in range from 4 - 16 */
	uint32_t CPHA;			/** Clock phase, should be:
								- SSP_CPHA_FIRST: first clock edge
								- SSP_CPHA_SECOND: second clock edge */
	uint32_t CPOL;			/** Clock polarity, should be:
								- SSP_CPOL_HI: high level
								- SSP_CPOL_LO: low level */
	uint32_t Mode;			/** SSP mode, should be:
								- SSP_MASTER_MODE: Master mode
								- SSP_SLAVE_MODE: Slave mode */
	uint32_t FrameFormat;	/** Frame Format:
								- SSP_FRAME_SPI: Motorola SPI frame format
								- SSP_FRAME_TI: TI frame format
								- SSP_FRAME_MICROWIRE: National Microwire frame format */
	uint32_t ClockRate;		/** Clock rate,in Hz */
} SSP_CFG_Type;



// Variables for sample chunks below
//static int16_t testsize[900];
int j;
int y=0;
int p;
int r;
int w;
int l;
int h;
int t;
int m;
int a;
int b=0;
int q=0;
int bb=0;
int qq=0;
int e;
int c;
int counter=0;
double g;
//int16_t buffer_size[8] = {0,4096,8192,12288,16384,20480,24576,28672};
//int buffer_size_dust[4]={0,16384,32768,49152};
float32_t val;
int Buffer_Full;
uint8_t *chptr;
double multiplier;
int16_t i=0;
int16_t SD_read_write_buff_increment[8]={0,512,1024,1536,2048,2560,3072,3584};
uint8_t gain=6;
uint8_t count=0;
uint8_t no_averages=12; // needs to be in multiples of 4
int check=0;
uint8_t buffer_size_choice=0;


int buffer_size_4096[16] = {0,8192,16384,24576,32768,40960,49152,57344,65536,73728,81920,90112,98304,106496,114688,122880}; // This is for 4096 FFT *** Too big?? I think the buffer is only 65536 bytes long
int buffer_size_2048[16] = {0,4096,8192,12288,16384,20480,24576,28672,32768,36864,40960,45056,49152,53248,57344,61440}; // This is for 2048 FFT
int buffer_size_1024[16] = {0,2048,4096,6144,8192,10240,12288,14336,16384,18432,20480,22528,24576,26624,28672,30720}; // for the 1024 FFT
int buffer_size_512[16] = {0,1024,2048,3072,4096,5120,6144,7168,8192,9216,10240,11264,12288,13312,14336,15360}; // for the 512 FFT
int buffer_size[16];

#define total_bytes_sampled 65536
#define FFTSIZE 1024 // this is working at 1024 (but makes our BW 40 kHz) 2048 is 20 kHz BW
#define FFTSIZE_512 512
int FFTSIZE_VARIABLE;
#define Sampling_Freq 100000
#define Frequency1 5000
#define Frequency2 30000


__DATA(RAM2) float32_t storage[FFTSIZE];
__DATA(RAM2) float32_t FFT[FFTSIZE];
__DATA(RAM2) float32_t PSD[FFTSIZE/2];
__DATA(RAM2) float32_t averagePSD[FFTSIZE/2];
__DATA(RAM2) unsigned char	SD_write_buff[512];
__DATA(RAM2) unsigned char	SD_read_buff[512];
__DATA(RAM2) float32_t standard_dev_summation_squared[FFTSIZE/2];
__DATA(RAM2) float32_t standard_dev_storage[FFTSIZE/2];
__DATA(RAM2) unsigned char data_to_send_UART[FFTSIZE*2];


__DATA(RAM2) float32_t storage_512[FFTSIZE_512];
__DATA(RAM2) float32_t FFT_512[FFTSIZE_512];
__DATA(RAM2) float32_t PSD_512[FFTSIZE_512/2];
__DATA(RAM2) float32_t averagePSD_512[FFTSIZE_512/2];
__DATA(RAM2) float32_t standard_dev_summation_squared_512[FFTSIZE_512/2];
__DATA(RAM2) float32_t standard_dev_storage_512[FFTSIZE_512/2];
__DATA(RAM2) unsigned char data_to_send_UART_512[FFTSIZE_512*2];
__DATA(RAM2) uint8_t number_of_SD_chunks_512=(FFTSIZE_512*2)/512;
uint8_t write_counter_512=0;

//debris variables
int buffer_size_dust[4]={0,16384,32768,49152};
__DATA(RAM2) float32_t storage_debris[total_bytes_sampled/8];
__DATA(RAM2) uint8_t storage_debris_array[64];
__DATA(RAM2) float storage_time_debris_array[64];
__DATA(RAM2) float storage_ranking_debris_array[64];
float32_t storage_average;
float32_t Standard_Dev_Debris;
int array_position;
float zeroCrossings;
float zeroCrossings2;
float zero_crossing_frequency;
float zero_crossing_frequency2;
__DATA(RAM2) float STDEV_Buffer_Debris[21]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
__DATA(RAM2) float MEAN_Buffer_Debris[21]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
__DATA(RAM2) float ZEROCROSS_Buffer_Debris[21]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
float median_Standard_Dev_Debris;
float median_Zero_Crossings_Debris;
float peak_value;
float quality_factor;
__DATA(RAM2)float median_Mean_Debris;
uint8_t Buffer_Counter_Debris=0;
uint8_t ZEROCROSS_Buffer_Counter_Debris=0;
uint8_t Calibrated_Debris=0;
uint8_t Zero_Crossings_Calibrated=0;
unsigned char data_to_send_UART_debris[512];
uint8_t write_status_flag=0;
extern ADC_DiffOrSingle=0; // 0 for dif and 1 for single ended
uint8_t Debris_Buffer_Sum;
uint8_t Read_Start_Next_Buff_Flag=0;
uint8_t Read_Start_Next_Buff_Counter=0;
int Random_Sample_Counter=0;
unsigned char data_to_send_UART_debris_addresses[2];


unsigned char I2C_ready_byte=0x02;
unsigned char I2C_receive_byte[2];
unsigned char command_call_back=0;
uint8_t start_bytes_PSD[5] = {0,1,2,3,4};
uint8_t start_bytes_SD[5] = {5,6,7,8,9};

uint8_t token;
uint8_t SD_init_return_status=0;
int32_t address_SD_card_write=1; // can be > 16777215 = 8 GB (current SD card is 16GB).
int32_t address_SD_card_read=1;
int	reading_flag=0;
//uint16_t SD_total_addresses=43201;// needs to be a multiple of 8 + 1 - this is an hour and a half
uint16_t SD_total_addresses=57;
uint8_t writestatus;
uint8_t number_of_SD_chunks=(FFTSIZE*2)/512; // might need this one for the 512 too...
uint8_t storageflag=0;
int sample_count;
__DATA(RAM2) float storage_send[512];
int time_counter=0;
uint32_t time_storage;
uint8_t finish_flag=0;

uint8_t test1;
uint8_t test2;
uint8_t test3;
uint8_t test4;

int minutes_run_time;
uint8_t mode;

// Test / Deployment mode setting variables
uint8_t SD_active=1; // 0 - SD card, 1 - no SD card
uint8_t Testing_Mode=2; // 0 - regular routine, 1 - test routine, 2 - UART Print 1024 FFT spectra mode

uint8_t debris_bytes_number_flag=0;


/******************************************************************************
 * Global Functions
 *****************************************************************************/

/**************************************************************************//**
 *
 * @brief   Systick callback function.
 *
 *****************************************************************************/
void SysTick_Handler(void)
{
  mstick++;
  //printf("\n test");
}

#ifdef DEBUG
/**************************************************************************//**
 *
 * @brief   Called from drivers with parameter errors
 *
 *****************************************************************************/
void check_failed(uint8_t *file, uint32_t line)
{
#if (ENABLE_LOGGING == OPT_ENABLED)
  log_i("check_failed at %s:%d\r\n", file, line);
#else
  (void)file;
  (void)line;
#endif
}
#endif

/******************************************************************************
 * Local Functions
 *****************************************************************************/

#if (ENABLE_LOGGING == OPT_ENABLED)
static void PrintGreeting(void)
{
  log_i("\r\n***************************************************\r\n");
  log_i("*                                                 *\r\n");
  log_i("* LabTool for LPC4357 OEM Boards...                *\r\n");
  log_i("* (C) Embedded Artists 2001-2012                  *\r\n");
  log_i("*                                                 *\r\n");
  log_i("*                           " __DATE__ ", " __TIME__ " *\r\n");
  log_i("***************************************************\r\n");

#if (ENABLE_MEASSURING == OPT_ENABLED)
  log_i("\r\n!!!!\r\n");
  log_i("!!!! Measuring is enabled, Analog IN/OUT and e2prom MAY FAIL\r\n");
  log_i("!!!!\r\n");
#endif
}
#endif


/**************************************************************************//**
 *
 * @brief   Configuration of all pins.
 *
 *****************************************************************************/
static void pinConfig(void)
{

  //-------------------------------------------------------------------------
  // SGPIO
  //-------------------------------------------------------------------------

  scu_pinmux(0x0,  0, SETTINGS_SGPIO, FUNC3); //SGPIO_0,  DIO0, J4-16
  scu_pinmux(0x2,  4, SETTINGS_SGPIO, FUNC0); //SGPIO_13, DIO1, J4-15
  scu_pinmux(0x2,  1, SETTINGS_SGPIO, FUNC0); //SGPIO_5,  DIO2, J4-14
  scu_pinmux(0x1,  6, SETTINGS_SGPIO, FUNC6); //SGPIO_14, DIO3, J4-13
  scu_pinmux(0x1, 15, SETTINGS_SGPIO, FUNC2); //SGPIO_2,  DIO4, J4-12
  scu_pinmux(0x1,  0, SETTINGS_SGPIO, FUNC6); //SGPIO_7,  DIO5, J4-11
  scu_pinmux(0x1, 14, SETTINGS_SGPIO, FUNC6); //SGPIO_10, DIO6, J4-10
  scu_pinmux(0x1, 13, SETTINGS_SGPIO, FUNC6); //SGPIO_9,  DIO7, J4-9
  scu_pinmux(0x1, 17, SETTINGS_SGPIO, FUNC6); //SGPIO_11, DIO8, J4-8
  scu_pinmux(0x1, 18, SETTINGS_SGPIO, FUNC6); //SGPIO_12, DIO9, J4-7
  scu_pinmux(0x1, 12, SETTINGS_SGPIO, FUNC6); //SGPIO_8,  DIO_CLK, J4-6

  /* Set doubled SGPIOs as input GPIOs to avoid conflicts */
  scu_pinmux(0x2,  0, SETTINGS_GPIO_IN, FUNC4); //GPIO5[0], ----, J4-16    (SGPIO_4)
  scu_pinmux(0x0,  1, SETTINGS_GPIO_IN, FUNC0); //GPIO0[1], ----, J4-14    (SGPIO_1)
  scu_pinmux(0x2,  2, SETTINGS_GPIO_IN, FUNC4); //GPIO5[2], ----, J4-12    (SGPIO_6)
  scu_pinmux(0x1, 16, SETTINGS_GPIO_IN, FUNC0); //GPIO0[3], ----, J4-11    (SGPIO_3)
  LPC_GPIO_PORT->DIR[5] &= ~(1UL << 0);
  LPC_GPIO_PORT->DIR[0] &= ~(1UL << 1);
  LPC_GPIO_PORT->DIR[5] &= ~(1UL << 2);
  LPC_GPIO_PORT->DIR[0] &= ~(1UL << 3);


  //-------------------------------------------------------------------------
  // GPIO
  //-------------------------------------------------------------------------

  /* Inputs/Outputs */
  scu_pinmux(0x1,  2, SETTINGS_GPIO_OUT, FUNC0); //GPIO0[9],  BOOT1
  scu_pinmux(0x1,  7, SETTINGS_GPIO_OUT, FUNC0); //GPIO1[0],  GPIO1_0
  LPC_GPIO_PORT->DIR[1] |= (1UL << 0);
  scu_pinmux(0x1,  8, SETTINGS_GPIO_OUT, FUNC0); //GPIO1[1],  GPIO1_1
  LPC_GPIO_PORT->DIR[1] |= (1UL << 1);
  scu_pinmux(0x1,  9, SETTINGS_GPIO_OUT, FUNC0); //GPIO1[2],  GPIO1_2
  LPC_GPIO_PORT->DIR[1] |= (1UL << 2);
  scu_pinmux(0x1, 10, SETTINGS_GPIO_OUT, FUNC0); //GPIO1[3],  GPIO1_3  available on J9-10
  LPC_GPIO_PORT->DIR[1] |= (1UL << 3);
  scu_pinmux(0x1, 11, SETTINGS_GPIO_OUT, FUNC0); //GPIO1[4],  GPIO1_4
  LPC_GPIO_PORT->DIR[1] |= (1UL << 4);

  scu_pinmux(0x6,  1, SETTINGS_GPIO_OUT, FUNC0); //GPIO3[0],  GPIO3_0
  LPC_GPIO_PORT->DIR[3] |= (1UL << 0);
  scu_pinmux(0x6,  2, SETTINGS_GPIO_OUT, FUNC0); //GPIO3[1],  GPIO3_1  available on J9-20
  LPC_GPIO_PORT->DIR[3] |= (1UL << 1);
  scu_pinmux(0x6,  4, SETTINGS_GPIO_OUT, FUNC0); //GPIO3[3],  GPIO3_3  available on J9-24 - all the above pins are configured to GPIO for SHDN and VGA control
  LPC_GPIO_PORT->DIR[3] |= (1UL << 3);
  scu_pinmux(0x6,  5, SETTINGS_GPIO_OUT, FUNC0); //GPIO3[4],  GPIO3_4
  LPC_GPIO_PORT->DIR[3] |= (1UL << 4); // LED

  scu_pinmux(0x2,  5, SETTINGS_GPIO_IN, FUNC4); //GPIO5[5],  GPIO5_5_JTAG_RESET
  scu_pinmux(0x2,  7, SETTINGS_GPIO_IN, FUNC0); //GPIO0[7],  ISP_N
  scu_pinmux(0x2,  8, SETTINGS_GPIO_IN, FUNC4); //GPIO5[7],  BOOT2
  scu_pinmux(0x2,  9, SETTINGS_GPIO_IN, FUNC0); //GPIO1[10], BOOT3
  scu_pinmux(0x2, 12, SETTINGS_GPIO_OUT, FUNC0); //GPIO1[12], GPIO1_12
  LPC_GPIO_PORT->DIR[1] |= (1UL << 12);
  scu_pinmux(0x2, 13, SETTINGS_GPIO_OUT, FUNC0); //GPIO1[13], GPIO1_13 available on J9-16
  LPC_GPIO_PORT->DIR[1] |= (1UL << 13);

  //Copies of GPIO settings for digital potentiometers
  scu_pinmux(0x1, 10, SETTINGS_GPIO_OUT, FUNC0); //GPIO1[3],  GPIO1_3  available on J9-10
  scu_pinmux(0x6,  2, SETTINGS_GPIO_OUT, FUNC0); //GPIO3[1],  GPIO3_1  available on J9-20
  scu_pinmux(0x6,  5, SETTINGS_GPIO_OUT, FUNC0); //GPIO3[4],  GPIO3_4  available on J9-24


  /* Outputs */
  scu_pinmux(0x2,  3, SETTINGS_GPIO_OUT, FUNC6); //GPIO5[3],  ISP_CTRL
  LPC_GPIO_PORT->DIR[5] |= (1UL << 3);
  LPC_GPIO_PORT->SET[5] |= (1UL << 3);

  scu_pinmux(0x2,  6, SETTINGS_GPIO_OUT, FUNC4); //GPIO5[6],  GPIO5_6_JTAG_RESET_TXEN
  LPC_GPIO_PORT->DIR[5] |= (1UL << 6);
  LPC_GPIO_PORT->CLR[5] |= (1UL << 6);

  /* Inputs for VGA control */
  scu_pinmux(0x6,   9, SETTINGS_GPIO_IN2, FUNC0); //GPIO3[5] for holding on while VGA is changed // this was byte 101
  LPC_GPIO_PORT->DIR[3] |= (0UL << 5);
  scu_pinmux(0x6,  11, SETTINGS_GPIO_IN3, FUNC0); //GPIO3[7] for VGA + gain // these are now for the LEDs RED
  LPC_GPIO_PORT->DIR[3] |= (1UL << 7);
  scu_pinmux(0x3,   2, SETTINGS_GPIO_IN2, FUNC4); //GPIO5[9] for VGA - gain // these are now for the LEDs GREEN
  LPC_GPIO_PORT->DIR[5] |= (1UL << 9);


  //-------------------------------------------------------------------------
  // Controls for DIO direction  (1-0  for Digital in, 0-1 for Digital out)
  //-------------------------------------------------------------------------

  scu_pinmux(0x1,  5, SETTINGS_GPIO_OUT, FUNC0); //GPIO1[8],  SGPIO15_TMS_SWDIO_TXEN, Controls buffer U7
  LPC_GPIO_PORT->DIR[1] |= (1UL << 8);
  LPC_GPIO_PORT->CLR[1] |= (1UL << 8);

  //#define SETTINGS_GPIO_OUT_UARTTX   (PUP_DISABLE | (0 << 3) | (0 << 5) |                 FILTER_ENABLE)
  //((1 << 4) | (0 << 3) |  |                 (0 << 7))
  //scu_pinmux(0x2, 10, SETTINGS_GPIO_OUT_UARTTX, FUNC2); //GPIO0[14], UART2_TXD, Controls buffer U4
  //#define USART3_SYN_REG = 0x400C2058;
  //SYNCCTRL;
  //#define SETTINGS_GPIO_OUT   (PUP_DISABLE | PDN_DISABLE | SLEWRATE_SLOW |                 FILTER_ENABLE)

  scu_pinmux(0x2, 10, SETTINGS_GPIO_OUT2, FUNC2); //GPIO0[14], UART2_TXD, Controls buffer U4
  //LPC_GPIO_PORT->DIR[0] |= (1UL << 14);
  //LPC_GPIO_PORT->SET[0] |= (1UL << 14);

  scu_pinmux(0x2, 11, SETTINGS_GPIO_OUT2, FUNC2); //GPIO1[11], UART2_RXD, Controls buffer U3
  //LPC_GPIO_PORT->DIR[1] |= (1UL << 11);
  //LPC_GPIO_PORT->CLR[1] |= (1UL << 11);

  //-------------------------------------------------------------------------
  // SSP
  //-------------------------------------------------------------------------

  scu_pinmux(0x1,  3, SETTINGS_SSP, FUNC5); //SSP1_MISO
  scu_pinmux(0x1,  4, SETTINGS_SSP2, FUNC5); //SSP1_MOSI
  scu_pinmux(0xF,  4, SETTINGS_SSP, FUNC0); //SSP1_SCK
  scu_pinmux(0x1, 20, SETTINGS_GPIO_OUT, FUNC0); //GPIO0[15], this is on J3-6, (SSP1_SEL on Link2 schematic)
  LPC_GPIO_PORT->DIR[0] |= (1UL << 15);

  //scu_pinmux(0x1,  20, SETTINGS_GPIO_OUT, FUNC0); //SSP1_SSEL *CS* We will also use GPIO for this
  //LPC_GPIO_PORT->SET[0] |= (1UL << 15); // CS set high


  // CS for DAC is controlled via P1.20 and not SSP1_SSEL.
  // Pin P1.20 should be configured as GPIO and set high.
 // scu_pinmux(0x1, 20, SETTINGS_GPIO_OUT, FUNC0); //GPIO0[15], available on J7-6
  //LPC_GPIO_PORT->DIR[0] |= (1UL << 15);
  //LPC_GPIO_PORT->SET[0] |= (1UL << 15);

  // CS for E2PROM is controlled via P3.2 and not SSP1_SSEL.
  // Pin P3.2 should be configured as GPIO and set high.
  //scu_pinmux(0x3,  2, SETTINGS_GPIO_OUT, FUNC4); //GPIO5[9], available on J7-12
  //LPC_GPIO_PORT->DIR[5] |= (1UL << 9);
  //LPC_GPIO_PORT->SET[5] |= (1UL << 9);

  // CS for GPO is controlled via P6.11 and not SSP1_SSEL.
  // Pin P6.11 should be configured as GPIO and set high.
  //scu_pinmux(0x6, 11, SETTINGS_GPIO_OUT, FUNC0); //GPIO3[7], available on J7-14
  //LPC_GPIO_PORT->DIR[3] |= (1UL << 7);
  //LPC_GPIO_PORT->SET[3] |= (1UL << 7);

  //-------------------------------------------------------------------------
  // SPIFI
  //-------------------------------------------------------------------------

//   scu_pinmux(0x3,  3, SETTINGS_SPIFI, FUNC3); //SPIFI_SCK
//   scu_pinmux(0x3,  4, SETTINGS_SPIFI, FUNC3); //SPIFI_SIO3
//   scu_pinmux(0x3,  5, SETTINGS_SPIFI, FUNC3); //SPIFI_SIO2
//   scu_pinmux(0x3,  6, SETTINGS_SPIFI, FUNC3); //SPIFI_MISO
//   scu_pinmux(0x3,  7, SETTINGS_SPIFI, FUNC3); //SPIFI_MOSI
//   scu_pinmux(0x3,  8, SETTINGS_SPIFI, FUNC3); //SPIFI_CS

  //-------------------------------------------------------------------------
  // LED
  //-------------------------------------------------------------------------

  /* Temporary use of the BOOT LED on the LPC Link-II as trigger LED to
     be able to set it from within an interrupt. The PCA9555 LEDs require
     I2C communication which should not be used from within an interrupt. */
  //scu_pinmux(0x1, 1, MD_PDN, FUNC0); // P1_1,FUNC0 => GPIO0[8]
  //LPC_GPIO_PORT->DIR[0] |= (1UL << 8);
  scu_pinmux(0x1, 1, SETTINGS_GPIO_OUT, FUNC0);
  LPC_GPIO_PORT->DIR[0] |= (1UL << 8);

  //-------------------------------------------------------------------------
  // Enabling/Disabling of I2C Monitoring (this is now being used for SD card but description remains)
  //-------------------------------------------------------------------------

  /* Control for SD card power default low (=off) */
  scu_pinmux(0x3,  1, SETTINGS_GPIO_OUT, FUNC4); //GPIO5[8],  CTRL_I2C_EN available on J7-11
  LPC_GPIO_PORT->DIR[5] |= (1UL << 8);
  LPC_GPIO_PORT->SET[5] |= (1UL << 8);


  //-------------------------------------------------------------------------
  // CALIBRATION SIGNAL
  //-------------------------------------------------------------------------

  //scu_pinmux(0x6,  9, SETTINGS_GPIO_OUT, FUNC5); //T2_MAT,  CAL_SIG available on J7-13


  //-------------------------------------------------------------------------
  // CLOCK OUTPUT
  //-------------------------------------------------------------------------

//  scu_pinmux(0x1, 19, ?, FUNC4); //CLKOUT, CGU_CLKOUT available on TP_P1_19
//  scu_pinmux(0x6,  0, ?, ?); // available on TP_P6_0
//  scu_pinmux(0x3,  0, ?, ?); // available on TP_P3_0


  //-------------------------------------------------------------------------
  // Antenna Deployment
  //-------------------------------------------------------------------------

  //GPIOs 3_5 and 3_7
  scu_pinmux(0x6,  9, SETTINGS_GPIO_OUT, FUNC0); //GPIO3[5] burn circuit control output
  LPC_GPIO_PORT->CLR[3] |= (1UL << 5); //setting to low initially
  scu_pinmux(0x6,  11, SETTINGS_GPIO_IN3, FUNC0); //GPIO3[7] burn circuit sensing input with pull-up // byte 203


}

static void Opamps_On(void)
{
	LPC_GPIO_PORT->SET[1] |= (1UL << 0); // OPA858_1 SHDN pin high (on)
	LPC_GPIO_PORT->SET[1] |= (1UL << 1); // OPA858_2 SHDN pin high (on)
	LPC_GPIO_PORT->SET[1] |= (1UL << 2); // THS4541 SHDN pin high (on)
	//LPC_GPIO_PORT->CLR[1] |= (1UL << 2); // THS4541 SHDN pin high (off)
	LPC_GPIO_PORT->SET[1] |= (1UL << 3); // OPA837_1 SHDN pin high (on)
	LPC_GPIO_PORT->SET[1] |= (1UL << 4); // OPA837_2 SHDN pin high (on)
	LPC_GPIO_PORT->CLR[1] |= (1UL << 12); // LMH6881 SHDN pin low (on)
	//LPC_GPIO_PORT->SET[3] |= (1UL << 4); // LED high (on)

}

static void Opamps_On_Debris(void) // not activating the THS4541
{
	LPC_GPIO_PORT->SET[1] |= (1UL << 0); // OPA858_1 SHDN pin high (on)
	LPC_GPIO_PORT->SET[1] |= (1UL << 1); // OPA858_2 SHDN pin high (on)
	//LPC_GPIO_PORT->SET[1] |= (1UL << 2); // THS4541 SHDN pin high (on)
	LPC_GPIO_PORT->SET[1] |= (1UL << 3); // OPA837_1 SHDN pin high (on)
	LPC_GPIO_PORT->SET[1] |= (1UL << 4); // OPA837_2 SHDN pin high (on)
	LPC_GPIO_PORT->CLR[1] |= (1UL << 12); // LMH6881 SHDN pin low (on)
	//LPC_GPIO_PORT->SET[3] |= (1UL << 4); // LED high (on)

}


static void Opamps_Off(void)
{
	LPC_GPIO_PORT->CLR[1] |= (1UL << 0); // OPA858_1 SHDN pin low (off)
	LPC_GPIO_PORT->CLR[1] |= (1UL << 1); // OPA858_2 SHDN pin low (off)
	LPC_GPIO_PORT->CLR[1] |= (1UL << 2); // THS4541 SHDN pin low (off)
	LPC_GPIO_PORT->CLR[1] |= (1UL << 3); // OPA837_1 SHDN pin low (off)
	LPC_GPIO_PORT->CLR[1] |= (1UL << 4); // OPA837_2 SHDN pin low (off)
	LPC_GPIO_PORT->SET[1] |= (1UL << 12); // LMH6881 SHDN pin high (off)
	//LPC_GPIO_PORT->CLR[3] |= (1UL << 4); // LED low (off)
}


void LMH6881_VGA_CONTROL(uint8_t gain)
{

	if (gain == 0) // gain of 2x (6db)
	{
		LPC_GPIO_PORT->SET[3] |= (1UL << 0);  // D0
		LPC_GPIO_PORT->CLR[1] |= (1UL << 13); // D1
		LPC_GPIO_PORT->CLR[3] |= (1UL << 1);  // D2
		LPC_GPIO_PORT->SET[3] |= (1UL << 3);  // D3
	}

	if (gain == 88) // gain of 2.5x (8db) // not used
	{
		LPC_GPIO_PORT->CLR[3] |= (1UL << 0);  // D0
		LPC_GPIO_PORT->SET[1] |= (1UL << 13); // D1
		LPC_GPIO_PORT->CLR[3] |= (1UL << 1);  // D2
		LPC_GPIO_PORT->SET[3] |= (1UL << 3);  // D3

	}

	if (gain == 10) // gain of 3.2x (10db) // not used
	{
		LPC_GPIO_PORT->CLR[3] |= (1UL << 0);  // D0
		LPC_GPIO_PORT->CLR[1] |= (1UL << 13); // D1
		LPC_GPIO_PORT->CLR[3] |= (1UL << 1);  // D2
		LPC_GPIO_PORT->SET[3] |= (1UL << 3);  // D3
	}

	if (gain == 12) // gain of 4x (12db) // not used
	{
		LPC_GPIO_PORT->SET[3] |= (1UL << 0);  // D0
		LPC_GPIO_PORT->SET[1] |= (1UL << 13); // D1
		LPC_GPIO_PORT->SET[3] |= (1UL << 1);  // D2
		LPC_GPIO_PORT->CLR[3] |= (1UL << 3);  // D3
	}

	if (gain == 14) // gain of 5x (14db) // not used
	{
		LPC_GPIO_PORT->SET[3] |= (1UL << 0);  // D0
		LPC_GPIO_PORT->CLR[1] |= (1UL << 13); // D1
		LPC_GPIO_PORT->SET[3] |= (1UL << 1);  // D2
		LPC_GPIO_PORT->CLR[3] |= (1UL << 3);  // D3
	}

	if (gain == 8) // gain of 6.3x (16db)
	{
		LPC_GPIO_PORT->CLR[3] |= (1UL << 0);  // D0
		LPC_GPIO_PORT->SET[1] |= (1UL << 13); // D1
		LPC_GPIO_PORT->SET[3] |= (1UL << 1);  // D2
		LPC_GPIO_PORT->CLR[3] |= (1UL << 3);  // D3
	}

	if (gain == 18) // gain of 8x (18db) // not used
	{
		LPC_GPIO_PORT->CLR[3] |= (1UL << 0);  // D0
		LPC_GPIO_PORT->CLR[1] |= (1UL << 13); // D1
		LPC_GPIO_PORT->SET[3] |= (1UL << 1);  // D2
		LPC_GPIO_PORT->CLR[3] |= (1UL << 3);  // D3
	}

	if (gain == 20) // gain of 10x (20db) // not used
	{
		LPC_GPIO_PORT->SET[3] |= (1UL << 0);  // D0
		LPC_GPIO_PORT->SET[1] |= (1UL << 13); // D1
		LPC_GPIO_PORT->CLR[3] |= (1UL << 1);  // D2
		LPC_GPIO_PORT->CLR[3] |= (1UL << 3);  // D3
	}

	if (gain == 16) // gain of 12.6x (22db)
	{
		LPC_GPIO_PORT->SET[3] |= (1UL << 0);  // D0
		LPC_GPIO_PORT->CLR[1] |= (1UL << 13); // D1
		LPC_GPIO_PORT->CLR[3] |= (1UL << 1);  // D2
		LPC_GPIO_PORT->CLR[3] |= (1UL << 3);  // D3
	}

	if (gain == 244) // gain of 15.8x (24db) // not used
	{
		LPC_GPIO_PORT->CLR[3] |= (1UL << 0);  // D0
		LPC_GPIO_PORT->SET[1] |= (1UL << 13); // D1
		LPC_GPIO_PORT->CLR[3] |= (1UL << 1);  // D2
		LPC_GPIO_PORT->CLR[3] |= (1UL << 3);  // D3
	}

	if (gain == 24) // gain of 20x (26db)
	{
		LPC_GPIO_PORT->CLR[3] |= (1UL << 0);  // D0
		LPC_GPIO_PORT->CLR[1] |= (1UL << 13); // D1
		LPC_GPIO_PORT->CLR[3] |= (1UL << 1);  // D2
		LPC_GPIO_PORT->CLR[3] |= (1UL << 3);  // D3
	}
}

/**
static void LMH6881_Gain_Adjust(void)
{
	//LPC_GPIO_PORT->SET[3] |= (1UL << 4); // LED high (on)
	if (LPC_GPIO_PORT->B[101])
	{
		LPC_GPIO_PORT->CLR[3] |= (1UL << 4); // LED high (off)
		if (LPC_GPIO_PORT->B[103])
		{
			while(count==0)
			{
				LPC_GPIO_PORT->SET[3] |= (1UL << 4); // LED high (on)
				if (gain<26)
				{gain=gain+2;}
				LMH6881_VGA_CONTROL(gain);
				count=1;
				while(LPC_GPIO_PORT->B[103])
				{}
	 			//printf("%d \n", gain);
			}
		}
		if (LPC_GPIO_PORT->B[169])
		{
			while(count==0)
			{
				LPC_GPIO_PORT->SET[3] |= (1UL << 4); // LED high (on)
				if (gain>=8)
				{gain=gain-2;}
				LMH6881_VGA_CONTROL(gain);
				count=1;
				while(LPC_GPIO_PORT->B[169])
				{}
	 			//printf("%d \n", gain);
			}
		}
		count=0;
	}
}
***/

void SD_Card_Power_On(void)
{
	LPC_GPIO_PORT->SET[5] |= (1UL << 8);

}

void SD_Card_Power_Off(void)
{
	LPC_GPIO_PORT->CLR[5] |= (1UL << 8);
}


/**************************************************************************//**
 *
 * @brief   Configuration of IRQ relative priorities.
 * @ingroup RES_IRQ
 *
 *****************************************************************************/
static void priorityConfig()
{
  /*
     The following modules use interrupts:

     SGPIO Capture:    SGPIO_IINT_IRQn, GINT0_IRQn
     VADC Capture:     VADC_IRQn + DMA_IRQn

     SGPIO Generator:  SGPIO_IINT_IRQn
     DAC Generator:    TIMER1_IRQn + TIMER3_IRQn

     Freq Counter:     SCT_IRQn

     I2C:              I2C0_IRQn + TIMER3_IRQn
     USB:              USB0_IRQn + USB1_IRQn

     Interprocess:     M0CORE_IRQn + M0_M4CORE_IRQn ??
     Systick:          SysTick_IRQn
     Timers:           ??
  */

  // Highest - Interprocess (to stop ongoing tasks, rarely occurs)
  //NVIC_SetPriority(M0CORE_IRQn,    0x00);
  //NVIC_SetPriority(M0_M4CORE_IRQn, 0x00);

  // High - Copying of samples
  NVIC_SetPriority(VADC_IRQn,        0x01);
  NVIC_SetPriority(SGPIO_IINT_IRQn,  0x01);
  NVIC_SetPriority(TIMER1_IRQn,      0x01);
  NVIC_SetPriority(TIMER3_IRQn,      0x01);

  // Standard - Trigger handling
  NVIC_SetPriority(DMA_IRQn,         0x02);
  NVIC_SetPriority(GINT0_IRQn,       0x02);
  NVIC_SetPriority(SCT_IRQn,         0x02);

  // Low - Communication
  NVIC_SetPriority(USB0_IRQn,        0x03);
  NVIC_SetPriority(USB1_IRQn,        0x03);
  NVIC_SetPriority(I2C0_IRQn,        0x03);
}

/**************************************************************************//**
 *
 * @brief   Sets up a 2KHz calibration signal.
 *
 *****************************************************************************/
static void setupCalibrationSignal()
{
#if 1
  TIM_TIMERCFG_Type timerCfg;
  TIM_MATCHCFG_Type matchCfg;

  // Initialize timer 2, prescale count time of 100uS
  timerCfg.PrescaleOption = TIM_PRESCALE_USVAL;
  timerCfg.PrescaleValue  = 100;

  // use channel 2, MR2
  matchCfg.MatchChannel = 2;
  // Disable interrupt when MR2 matches the value in TC register
  matchCfg.IntOnMatch   = FALSE;
  //Enable reset on MR2: TIMER will reset if MR2 matches it
  matchCfg.ResetOnMatch = TRUE;
  //Stop on MR2 if MR2 matches it
  matchCfg.StopOnMatch  = FALSE;
  //Toggle MR2.2 pin if MR2 matches it
  matchCfg.ExtMatchOutputType = TIM_EXTMATCH_TOGGLE;
  // Set Match value, count value of 5 (5 * 100uS = 0.5mS --> 2KHz)
  matchCfg.MatchValue   = 4;

  TIM_Init(LPC_TIMER2, TIM_TIMER_MODE, &timerCfg);
  TIM_ConfigMatch(LPC_TIMER2, &matchCfg);
  TIM_Cmd(LPC_TIMER2, ENABLE);
#else
  scu_pinmux(0x6,  9, SETTINGS_GPIO_OUT, FUNC0); //GPIO3[5],  CAL_SIG available on J7-13
  LPC_GPIO_PORT->DIR[3] |= (1UL << 5);
  //LPC_GPIO_PORT->SET[3] |= (1UL << 5); //SET => 0V out
  LPC_GPIO_PORT->CLR[3] |= (1UL << 5); //CLR => 1.253V out
#endif
}



void Array_sort(float *array , int n)
{
    // declare some local variables
    int i=0 , j=0;
    float temp=0;

    for(i=0 ; i<n ; i++)
    {
        for(j=0 ; j<n-1 ; j++)
        {
            if(array[j]>array[j+1])
            {
                temp        = array[j];
                array[j]    = array[j+1];
                array[j+1]  = temp;
            }
        }
    }
}


void Antenna_Deployment()
{

	uint8_t sucessful=0x02;
	uint8_t unsucessful=0x09;


	// all we have to do is write to the correct GPIO to deploy the antenna, then check for the status of the other GPIO
	LPC_GPIO_PORT->SET[3] |= (1UL << 5); //setting to high
	LPC_GPIO_PORT->SET[5] |= (1UL << 9); // red

	TIM_Waitms(5000);

	LPC_GPIO_PORT->CLR[3] |= (1UL << 5); //setting to low
	LPC_GPIO_PORT->CLR[5] |= (1UL << 9); // red

	TIM_Waitms(1000);

	LPC_GPIO_PORT->SET[3] |= (1UL << 5); //setting to high
	LPC_GPIO_PORT->SET[5] |= (1UL << 9); // red

	TIM_Waitms(5000);

	LPC_GPIO_PORT->CLR[3] |= (1UL << 5); //setting to low
	LPC_GPIO_PORT->CLR[5] |= (1UL << 9); // red

	TIM_Waitms(1000);



	if (LPC_GPIO_PORT->B[103]) // this is unsuccessful
	{

		I2C_S_SETUP_Type I2C_S_SETUP_Type;
		I2C_S_SETUP_Type.tx_data=unsucessful;
		I2C_S_SETUP_Type.tx_length=1;
		I2C_S_SETUP_Type.rx_data=I2C_receive_byte;
		I2C_S_SETUP_Type.rx_length=2;



		LPC_GPIO_PORT->SET[5] |= (1UL << 9); // red
		// send a certain byte
		while(!(I2C_receive_byte[0]==16))
		{
			I2C_SlaveTransferData(I2C_PORT, &I2C_S_SETUP_Type, 0);
		}

		I2C_receive_byte[0]=0; // always have this after the command byte to reset command

		I2C_Cmd(I2C_PORT, DISABLE);

		LPC_GPIO_PORT->CLR[5] |= (1UL << 9); // red

	}

	else // this is successful
	{

		I2C_S_SETUP_Type I2C_S_SETUP_Type;
		I2C_S_SETUP_Type.tx_data=sucessful;
		I2C_S_SETUP_Type.tx_length=1;
		I2C_S_SETUP_Type.rx_data=I2C_receive_byte;
		I2C_S_SETUP_Type.rx_length=2;


		LPC_GPIO_PORT->SET[3] |= (1UL << 4); // blue

		// send another byte
		while(!(I2C_receive_byte[0]==16))
		{
			I2C_SlaveTransferData(I2C_PORT, &I2C_S_SETUP_Type, 0);
		}

		I2C_receive_byte[0]=0; // always have this after the command byte to reset command

		I2C_Cmd(I2C_PORT, DISABLE);

		LPC_GPIO_PORT->CLR[3] |= (1UL << 4); // blue

	}

}


void FFT_1024_SD_saving(int minutes_run_time_func_1024, uint8_t averages_1024)
{


	if (minutes_run_time_func_1024==0)
	{
		SD_total_addresses=241; // 30 seconds
		//SD_total_addresses=4801; 10 minutes
		//SD_total_addresses=57; 14 x 512 buffers
	}
	else
	{
		SD_total_addresses=(minutes_run_time_func_1024*8640)+1; // this function writes 8 addresses a second (480 a minute) but starts at 1 so we need to convert minutes into addresses
		// using this line. Also the value we get from the I2C is /18 less than the actual number of minutes we want so we need to multiply by 4 again
		// to work out how many buffers transfered you -1 and divide by 4
	}

	ADC_DiffOrSingle=0; // 0 for differential

	// capture VADC settings
	capture_cfg_t cfg;
	cfg.numEnabledVADC = 0x01;
	cfg.numEnabledSGPIO = 0;
	cfg.sampleRate = 40000000;// can't be less than 20kHz
	cfg.vadc.enabledChannels = (0x1 << 1);
	cfg.vadc.enabledTriggers = (0x0 << 0);
	cfg.vadc.voltPerDiv = (0 << 0);
	cfg.vadc.noiseReduction = (0 << 0);
	cfg.vadc.couplings = (1 << 0);
	cfg.postFill = 0x264; // ... 10011000100 for 16 samples and 100 percent buffer filled <- SET TO 50%??
	cfg.vadc.triggerSetup = (0x0 << 14);

	capture_Configure(&cfg, sizeof(cfg));


	// This is the default FFTSIZE (1024)
	// values in here have to be FFTSIZE
	arm_rfft_fast_instance_f32 *S = malloc(sizeof(arm_rfft_fast_instance_f32));
	S->fftLenRFFT = FFTSIZE;
	S->pTwiddleRFFT    = (float32_t *) twiddleCoef_rfft_1024;

	// values in here have to be FFTSIZE/2 (except for fftLen)
	arm_cfft_instance_f32 *Sint = malloc(sizeof(arm_cfft_instance_f32));
	Sint = &(S->Sint);
	Sint->fftLen = FFTSIZE;
	Sint->pTwiddle     = (float32_t *) twiddleCoef_512;
	Sint->bitRevLength = ARMBITREVINDEXTABLE_512_TABLE_LENGTH;
	Sint->pBitRevTable = (uint16_t *)armBitRevIndexTable512;

	I2C_S_SETUP_Type I2C_S_SETUP_Type;
	I2C_S_SETUP_Type.tx_data=data_to_send_UART;
	I2C_S_SETUP_Type.tx_length=FFTSIZE*2; // this is 2048 bytes
	I2C_S_SETUP_Type.rx_data=I2C_receive_byte;
	I2C_S_SETUP_Type.rx_length=2;


	//no_averages=20; // as many as can be done in a second (this could be less if we want to give time for possible SD card write errors)
	no_averages=averages_1024;

	mstick=0; //reset timer -- should be last thing done before while() starts.

	while(finish_flag==0) // to undo this make it while(1) and take out the finish_flag=1 from the bottom of the script.
	{

		LPC_GPIO_PORT->SET[3] |= (1UL << 4); // LED high (on)
		Opamps_On(); //think about turning these back on later.

		b=0;
		q=0;
		bb=0;
		qq=0;

		while(b==q || q==bb || bb==qq)
		{
			b = (rand() % 15);
			q = (rand() % 15);
			bb = (rand() % 15);
			qq = (rand() % 15);

		} // for selecting 4 random chunks of data from a sample buffer


		int random_numbers[4] = {b,q,bb,qq};

		Buffer_Full = 0;
		capture_Arm(); // start sample capture
		while (Buffer_Full<21) // waiting for 21 DMA interrupts meaning the entire buffer is full
		{}
		capture_Disarm(); // stop sample capture


		Opamps_Off(); //think about turning these back on later.



		for (p=0;p<4;p++) //
		{

			for (j=0;j<(FFTSIZE*2);j+=2)
			{
				int16_t *pointer = (0x20000000 + buffer_size_1024[random_numbers[p]] + j); /* Reading the
				integer value from the address pointed by ptr and storing it to the array "storage" (two lines down)*/
				val =  *pointer; // converting from int16_t to float
				storage[j/2] = (val-6144)*0.0001953125;//((val-4096)-311)/7801.4; //(((val-4096)-348.8)/4620.3)-0.362; //(((val-4096) + 404.5) / 4656)-0.564; // converting from bit to voltage. 3691.5
			}


			//Hann windowing
			for (i=0; i < FFTSIZE; i++)
			{multiplier = 0.5 * (1 - cos(2*PI*i/(FFTSIZE-1)));storage[i] = multiplier * storage[i];} // double check this function with FFTSIZe

			//FFT
			arm_rfft_fast_f32(S,storage,FFT,0);
			// magnitude squared
			arm_cmplx_mag_squared_f32(FFT, PSD, FFTSIZE/2);

			// Summation for standard deviation calculation later on
			for(e=0;e<FFTSIZE/2;e++)
			{standard_dev_summation_squared[e] = standard_dev_summation_squared[e] + pow(PSD[e],2);}

			// dividing by no_averages and adding to averagePSD
			for (m=0;m<FFTSIZE/2;m++)
			{averagePSD[m] = averagePSD[m]+(PSD[m]/no_averages);}


			counter++;


			if (counter == no_averages)
			{

				time_storage=mstick;

				time_counter++;


				while ((mstick/1000)<time_counter)
				{
					LPC_GPIO_PORT->SET[5] |= (1UL << 9); // red
				}
				LPC_GPIO_PORT->CLR[5] |= (1UL << 9); // red // green on debris

				LPC_GPIO_PORT->CLR[3] |= (1UL << 4); // LED high (off)

				// Calculate the SD
				for (c=0;c<FFTSIZE/2;c++)
				{standard_dev_storage[c] = sqrt((standard_dev_summation_squared[c]/no_averages)-(pow(averagePSD[c],2)));}

				standard_dev_storage[(FFTSIZE/2)-1]=time_storage;

				counter=0;


				if (address_SD_card_write<SD_total_addresses)
				{

					LPC_GPIO_PORT->SET[3] |= (1UL << 7);

					for (int ii=0;ii<2;ii++)
					{

						if (ii==0)
						{
							// convert float array to byte array (averagePSD float array -> data_to_send_UART byte array
							chptr = (uint8_t *) &averagePSD;
							for (a=0;a<(FFTSIZE*2);a++) // need to change the lengths here for 1024 FFT
							{data_to_send_UART[a] = *chptr;*chptr++;}

						}
						if (ii==1)
						{
							// convert float array to byte array (averagePSD float array -> data_to_send_UART byte array
							chptr = (uint8_t *) &standard_dev_storage;
							for (a=0;a<(FFTSIZE*2);a++) // need to change the lengths here for 1024 FFT
							{data_to_send_UART[a] = *chptr;*chptr++;}

						}

						for (int y=0;y<number_of_SD_chunks;y++)
						{
							for (int j=0;j<512;j++)
							{
								SD_write_buff[j]=data_to_send_UART[j+SD_read_write_buff_increment[y]];
							}


							// sending data to SD card

							writestatus=0;

							spi_control_init(); // Initialization of SD card.

							SD_Card_Power_On();

							while (!(writestatus==12))
							{
								SD_init_return_status=0;

								while(!(SD_init_return_status==5))
								{
									SD_init_return_status = spi_SD_init(LPC_SSP1); // SPEED CLOCK RATE UP?

									if (SD_init_return_status==5)
									{
										//printf("SD Card Initialization Complete \n");
										LPC_GPIO_PORT->CLR[5] |= (1UL << 9); // red
										break;
									}

									if (!(SD_init_return_status==5))
									{
										SD_Card_Power_Off();
										TIM_Waitus(50); // testing 100 us
										SD_Card_Power_On();
										LPC_GPIO_PORT->SET[5] |= (1UL << 9); // red
									}
									if (i==5000)
									{
										//printf("SD Card Not Initialized \n");
										SD_init_return_status=5; // break while
										LPC_GPIO_PORT->SET[5] |= (1UL << 9); // red
									}
									i++;
								}

								writestatus=SD_writeSingleBlock(address_SD_card_write,SD_write_buff,&token,LPC_SSP1);

								write_counter_512++;

								if (write_counter_512==3)
								{
									LPC_GPIO_PORT->SET[5] |= (1UL << 9); // red
									break; // try to write 10 times, and if still doesn't work, skip that data and move on.

								}

							}
							write_counter_512=0;

							/****

							writestatus=SD_writeSingleBlock(address_SD_card_write,SD_write_buff,&token,LPC_SSP1);

							if (writestatus==9)
							{

								SD_Card_Power_Off();
								SD_Card_Power_On();
								SD_init_return_status=0;

								while(!(SD_init_return_status==5))
								{
									SD_init_return_status = spi_SD_init(LPC_SSP1); // SPEED CLOCK RATE UP?

									if (SD_init_return_status==5)
									{
										//printf("SD Card Initialization Complete \n");
										break;
									}

									if (!(SD_init_return_status==5))
									{
										SD_Card_Power_Off();
										TIM_Waitus(50);
										SD_Card_Power_On();
									}
									if (i==5000)
									{
										SD_init_return_status=5; // break while
									}

									i++;
								}

							}

							****/

							address_SD_card_write++;

							LPC_GPIO_PORT->CLR[3] |= (1UL << 7);
						}
					}
				}


				//reading from card and printing to UART
				if (address_SD_card_write==SD_total_addresses)
				{

					for(int flight=0;flight<4;flight++)
					{
						LPC_GPIO_PORT->SET[3] |= (1UL << 4); // LED high (on) blue
						TIM_Waitms(20);
						LPC_GPIO_PORT->CLR[3] |= (1UL << 4); // LED high (on) blue
						TIM_Waitms(20);
						LPC_GPIO_PORT->SET[5] |= (1UL << 9); // red
						TIM_Waitms(20);
						LPC_GPIO_PORT->CLR[5] |= (1UL << 9); // red
						TIM_Waitms(20);
					}


					address_SD_card_write=1;
					reading_flag=1;
					//printf("Starting Read and UART Print \n");
				}

				if (reading_flag==1)
				{

					Opamps_Off();

					while(address_SD_card_write<SD_total_addresses)
					{
						for (int y=0;y<number_of_SD_chunks;y++)
							{
							LPC_GPIO_PORT->SET[5] |= (1UL << 9); // red
							SD_readSingleBlock(address_SD_card_write,SD_read_buff,&token,LPC_SSP1);
							address_SD_card_write++;
							LPC_GPIO_PORT->CLR[5] |= (1UL << 9); // red
							for (int j=0;j<512;j++)
							{
								data_to_send_UART[j+SD_read_write_buff_increment[y]]=SD_read_buff[j];
							}

						}


						LPC_GPIO_PORT->SET[3] |= (1UL << 4); // LED high (on) blue
						I2C_Cmd(I2C_PORT, ENABLE);

						while(!(I2C_receive_byte[0]==16))
						{
							I2C_SlaveTransferData(I2C_PORT, &I2C_S_SETUP_Type, 0);
						}
						I2C_receive_byte[0]=0; // always have this after the command byte to reset command

						I2C_Cmd(I2C_PORT, DISABLE);

						LPC_GPIO_PORT->CLR[3] |= (1UL << 4); // LED high (on) blue


						/*** HERE

						LPC_GPIO_PORT->SET[3] |= (1UL << 4); // LED high (on) blue

						UART_TxCmd(LPC_USART2,ENABLE);

						// send start bytes
						for (int v=0;v<5;v++)
						{UART_SendByte(LPC_USART2,start_bytes_PSD[v]);}

						// send average PSD and SD (separately)
						for (int v=0;v<FFTSIZE*2;v++)
						{UART_SendByte(LPC_USART2,data_to_send_UART[v]);}

						UART_TxCmd(LPC_USART2,DISABLE);

						LPC_GPIO_PORT->CLR[3] |= (1UL << 4); // LED high (on) blue

						TIM_Waitms(50);
						***/ //TO HERE
					}

				}

				if (reading_flag==1)
				{
					address_SD_card_write=1;
					reading_flag=0;
					mstick=0;
					time_counter=0;
					finish_flag=1;
				}



				// zero averagePSD array
				for (int v=0;v<FFTSIZE/2;v++)
				{averagePSD[v] = averagePSD[v] * 0;}

				// zero SD^2 array
				for (int v=0;v<FFTSIZE/2;v++)
				{standard_dev_summation_squared[v] = standard_dev_summation_squared[v] * 0;}

				// zero SD_storage array
				for (int v=0;v<FFTSIZE/2;v++)
				{standard_dev_storage[v] = standard_dev_storage[v] * 0;}

			}
		}
	}
	finish_flag=0;
}



void FFT_1024_UART_Print(int minutes_run_time_func_1024, uint8_t averages_1024)
{


	if (minutes_run_time_func_1024==0)
	{
		SD_total_addresses=241; // 30 seconds
		//SD_total_addresses=4801; 10 minutes
		//SD_total_addresses=57; 14 x 512 buffers
	}
	else
	{
		SD_total_addresses=(minutes_run_time_func_1024*8640)+1; // this function writes 8 addresses a second (480 a minute) but starts at 1 so we need to convert minutes into addresses
		// using this line. Also the value we get from the I2C is /18 less than the actual number of minutes we want so we need to multiply by 4 again
		// to work out how many buffers transfered you -1 and divide by 4
	}

	ADC_DiffOrSingle=0; // 0 for differential

	// capture VADC settings
	capture_cfg_t cfg;
	cfg.numEnabledVADC = 0x01;
	cfg.numEnabledSGPIO = 0;
	cfg.sampleRate = 40000000;// can't be less than 20kHz
	cfg.vadc.enabledChannels = (0x1 << 1);
	cfg.vadc.enabledTriggers = (0x0 << 0);
	cfg.vadc.voltPerDiv = (0 << 0);
	cfg.vadc.noiseReduction = (0 << 0);
	cfg.vadc.couplings = (1 << 0);
	cfg.postFill = 0x264; // ... 10011000100 for 16 samples and 100 percent buffer filled <- SET TO 50%??
	cfg.vadc.triggerSetup = (0x0 << 14);

	capture_Configure(&cfg, sizeof(cfg));


	// This is the default FFTSIZE (1024)
	// values in here have to be FFTSIZE
	arm_rfft_fast_instance_f32 *S = malloc(sizeof(arm_rfft_fast_instance_f32));
	S->fftLenRFFT = FFTSIZE;
	S->pTwiddleRFFT    = (float32_t *) twiddleCoef_rfft_1024;

	// values in here have to be FFTSIZE/2 (except for fftLen)
	arm_cfft_instance_f32 *Sint = malloc(sizeof(arm_cfft_instance_f32));
	Sint = &(S->Sint);
	Sint->fftLen = FFTSIZE;
	Sint->pTwiddle     = (float32_t *) twiddleCoef_512;
	Sint->bitRevLength = ARMBITREVINDEXTABLE_512_TABLE_LENGTH;
	Sint->pBitRevTable = (uint16_t *)armBitRevIndexTable512;

	I2C_S_SETUP_Type I2C_S_SETUP_Type;
	I2C_S_SETUP_Type.tx_data=data_to_send_UART;
	I2C_S_SETUP_Type.tx_length=FFTSIZE*2; // this is 2048 bytes
	I2C_S_SETUP_Type.rx_data=I2C_receive_byte;
	I2C_S_SETUP_Type.rx_length=2;


	//no_averages=20; // as many as can be done in a second (this could be less if we want to give time for possible SD card write errors)
	no_averages=averages_1024;

	mstick=0; //reset timer -- should be last thing done before while() starts.

	while(finish_flag==0) // to undo this make it while(1) and take out the finish_flag=1 from the bottom of the script.
	{

		LPC_GPIO_PORT->SET[3] |= (1UL << 4); // LED high (on)
		Opamps_On(); //think about turning these back on later.

		b=0;
		q=0;
		bb=0;
		qq=0;

		while(b==q || q==bb || bb==qq)
		{
			b = (rand() % 15);
			q = (rand() % 15);
			bb = (rand() % 15);
			qq = (rand() % 15);

		} // for selecting 4 random chunks of data from a sample buffer


		int random_numbers[4] = {b,q,bb,qq};

		Buffer_Full = 0;
		capture_Arm(); // start sample capture
		while (Buffer_Full<21) // waiting for 21 DMA interrupts meaning the entire buffer is full
		{}
		capture_Disarm(); // stop sample capture


		Opamps_Off(); //think about turning these back on later.



		for (p=0;p<4;p++) //
		{

			for (j=0;j<(FFTSIZE*2);j+=2)
			{
				int16_t *pointer = (0x20000000 + buffer_size_1024[random_numbers[p]] + j); /* Reading the
				integer value from the address pointed by ptr and storing it to the array "storage" (two lines down)*/
				val =  *pointer; // converting from int16_t to float
				storage[j/2] = (val-6144)*0.0001953125;//((val-4096)-311)/7801.4; //(((val-4096)-348.8)/4620.3)-0.362; //(((val-4096) + 404.5) / 4656)-0.564; // converting from bit to voltage. 3691.5
			}


			//Hann windowing
			for (i=0; i < FFTSIZE; i++)
			{multiplier = 0.5 * (1 - cos(2*PI*i/(FFTSIZE-1)));storage[i] = multiplier * storage[i];} // double check this function with FFTSIZe

			//FFT
			arm_rfft_fast_f32(S,storage,FFT,0);
			// magnitude squared
			arm_cmplx_mag_squared_f32(FFT, PSD, FFTSIZE/2);

			// Summation for standard deviation calculation later on
			for(e=0;e<FFTSIZE/2;e++)
			{standard_dev_summation_squared[e] = standard_dev_summation_squared[e] + pow(PSD[e],2);}

			// dividing by no_averages and adding to averagePSD
			for (m=0;m<FFTSIZE/2;m++)
			{averagePSD[m] = averagePSD[m]+(PSD[m]/no_averages);}


			counter++;


			if (counter == no_averages)
			{

				time_storage=mstick;

				time_counter++;


				while ((mstick/1000)<time_counter)
				{
					LPC_GPIO_PORT->SET[5] |= (1UL << 9); // red
				}
				LPC_GPIO_PORT->CLR[5] |= (1UL << 9); // red // green on debris

				LPC_GPIO_PORT->CLR[3] |= (1UL << 4); // LED high (off)

				// Calculate the SD
				for (c=0;c<FFTSIZE/2;c++)
				{standard_dev_storage[c] = sqrt((standard_dev_summation_squared[c]/no_averages)-(pow(averagePSD[c],2)));}

				standard_dev_storage[(FFTSIZE/2)-1]=time_storage;

				counter=0;


				LPC_GPIO_PORT->SET[3] |= (1UL << 7);

				for (int ii=0;ii<2;ii++)
				{

					if (ii==0)
					{
						// convert float array to byte array (averagePSD float array -> data_to_send_UART byte array
						chptr = (uint8_t *) &averagePSD;
						for (a=0;a<(FFTSIZE*2);a++) // need to change the lengths here for 1024 FFT
						{data_to_send_UART[a] = *chptr;*chptr++;}

					}
					if (ii==1)
					{
						// convert float array to byte array (averagePSD float array -> data_to_send_UART byte array
						chptr = (uint8_t *) &standard_dev_storage;
						for (a=0;a<(FFTSIZE*2);a++) // need to change the lengths here for 1024 FFT
						{data_to_send_UART[a] = *chptr;*chptr++;}

					}


					LPC_GPIO_PORT->SET[3] |= (1UL << 4); // LED high (on) blue

					UART_TxCmd(LPC_USART2,ENABLE);

					// send start bytes
					for (int v=0;v<5;v++)
					{UART_SendByte(LPC_USART2,start_bytes_PSD[v]);}

					// send average PSD and SD (separately)
					for (int v=0;v<FFTSIZE*2;v++)
					{UART_SendByte(LPC_USART2,data_to_send_UART[v]);}

					UART_TxCmd(LPC_USART2,DISABLE);

					LPC_GPIO_PORT->CLR[3] |= (1UL << 4); // LED high (on) blue

					TIM_Waitms(50);



				}

				// zero averagePSD array
				for (int v=0;v<FFTSIZE/2;v++)
				{averagePSD[v] = averagePSD[v] * 0;}

				// zero SD^2 array
				for (int v=0;v<FFTSIZE/2;v++)
				{standard_dev_summation_squared[v] = standard_dev_summation_squared[v] * 0;}

				// zero SD_storage array
				for (int v=0;v<FFTSIZE/2;v++)
				{standard_dev_storage[v] = standard_dev_storage[v] * 0;}

			}
		}
	}

	finish_flag=0;
}



void FFT_512_SD_saving(int minutes_run_time_func_512, uint8_t averages_512)
{


	if (minutes_run_time_func_512==0)
	{
		SD_total_addresses=61; // 15 seconds
		// 10 minutes // formula is 4 per second so addresses = 4 * 60 * minutes + 1 (+1 is because the addresses start at 1).
	}
	else
	{
		SD_total_addresses=minutes_run_time_func_512*4320+1; // this function writes 4 addresses a second (240 a minute) but starts at 1 so we need to convert minutes into addresses
		// using this line. Also the value we get from the I2C is /18 less than the actual number of minutes we want so we need to multiply by 4 again
	}

	//SD_total_addresses = 57; // just for testing

	I2C_S_SETUP_Type I2C_S_SETUP_Type;
	I2C_S_SETUP_Type.tx_data=data_to_send_UART_512;
	I2C_S_SETUP_Type.tx_length=FFTSIZE_512*2; //this is 1024 bytes
	I2C_S_SETUP_Type.rx_data=I2C_receive_byte;
	I2C_S_SETUP_Type.rx_length=2;

	ADC_DiffOrSingle=0;

	// capture VADC settings
	capture_cfg_t cfg;
	cfg.numEnabledVADC = 0x01;
	cfg.numEnabledSGPIO = 0;
	cfg.sampleRate = 40000000;// can't be less than 20kHz
	cfg.vadc.enabledChannels = (0x1 << 1);
	cfg.vadc.enabledTriggers = (0x0 << 0);
	cfg.vadc.voltPerDiv = (0 << 0);
	cfg.vadc.noiseReduction = (0 << 0);
	cfg.vadc.couplings = (1 << 0);
	cfg.postFill = 0x264; // ... 10011000100 for 16 samples and 100 percent buffer filled <- SET TO 50%??
	cfg.vadc.triggerSetup = (0x0 << 14);

	capture_Configure(&cfg, sizeof(cfg));


	// values in here have to be FFTSIZE
	arm_rfft_fast_instance_f32 *S = malloc(sizeof(arm_rfft_fast_instance_f32));
	S->fftLenRFFT = 512;
	S->pTwiddleRFFT    = (float32_t *) twiddleCoef_rfft_512;

	// values in here have to be FFTSIZE/2 (except for fftLen)
	arm_cfft_instance_f32 *Sint = malloc(sizeof(arm_cfft_instance_f32));
	Sint = &(S->Sint);
	Sint->fftLen = 512;
	Sint->pTwiddle     = (float32_t *) twiddleCoef_256;
	Sint->bitRevLength = ARMBITREVINDEXTABLE_256_TABLE_LENGTH;
	Sint->pBitRevTable = (uint16_t *)armBitRevIndexTable256;

	//no_averages=40;
	no_averages=averages_512;

	mstick=0; //reset timer -- should be last thing done before while() starts.

	while(finish_flag==0) // to undo this make it while(1) and take out the finish_flag=1 from the bottom of the script.
	{

		LPC_GPIO_PORT->SET[3] |= (1UL << 4); // LED high (on)
		Opamps_On(); //think about turning these back on later.

		b=0;
		q=0;
		bb=0;
		qq=0;

		while(b==q || q==bb || bb==qq)
		{
			b = (rand() % 15);
			q = (rand() % 15);
			bb = (rand() % 15);
			qq = (rand() % 15);

		} // for selecting 4 random chunks of data from a sample buffer


		int random_numbers[4] = {b,q,bb,qq};

		Buffer_Full = 0;
		capture_Arm(); // start sample capture
		while (Buffer_Full<21) // waiting for 21 DMA interrupts meaning the entire buffer is full
		{}
		capture_Disarm(); // stop sample capture


		Opamps_Off(); //think about turning these back on later.



		for (p=0;p<4;p++) //
		{

			for (j=0;j<(FFTSIZE_512*2);j+=2)
			{
				int16_t *pointer = (0x20000000 + buffer_size_512[random_numbers[p]] + j); /* Reading the
				integer value from the address pointed by ptr and storing it to the array "storage" (two lines down)*/
				val =  *pointer; // converting from int16_t to float
				storage_512[j/2] = (val-6144)*0.0001953125;// converting from bit to voltage.
			}

			//Hann windowing
			for (i=0; i < FFTSIZE_512; i++)
			{multiplier = 0.5 * (1 - cos(2*PI*i/(FFTSIZE_512-1)));storage_512[i] = multiplier * storage_512[i];} // double check this function with FFTSIZe

			//FFT
			arm_rfft_fast_f32(S,storage_512,FFT_512,0);
			// magnitude squared
			arm_cmplx_mag_squared_f32(FFT_512, PSD_512, FFTSIZE_512/2);

			// Summation for standard deviation calculation later on
			for(e=0;e<FFTSIZE_512/2;e++)
			{standard_dev_summation_squared_512[e] = standard_dev_summation_squared_512[e] + pow(PSD_512[e],2);}

			// dividing by no_averages and adding to averagePSD
			for (m=0;m<FFTSIZE_512/2;m++)
			{averagePSD_512[m] = averagePSD_512[m]+(PSD_512[m]/no_averages);}


			counter++;


			if (counter == no_averages)
			{

				time_storage=mstick;

				time_counter++;


				while ((mstick/1000)<time_counter)
				{
					LPC_GPIO_PORT->SET[5] |= (1UL << 9); // red
				}
				LPC_GPIO_PORT->CLR[5] |= (1UL << 9); // red

				LPC_GPIO_PORT->CLR[3] |= (1UL << 4); // LED high (off)

				// Calculate the SD
				for (c=0;c<FFTSIZE_512/2;c++)
				{standard_dev_storage_512[c] = sqrt((standard_dev_summation_squared_512[c]/no_averages)-(pow(averagePSD_512[c],2)));}

				standard_dev_storage_512[(FFTSIZE_512/2)-1]=time_storage;

				counter=0;


				if (address_SD_card_write<SD_total_addresses)
				{
					LPC_GPIO_PORT->SET[3] |= (1UL << 7);

					for (int ii=0;ii<2;ii++)
					{

						if (ii==0)
						{
							// convert float array to byte array (averagePSD float array -> data_to_send_UART byte array
							chptr = (uint8_t *) &averagePSD_512;
							for (a=0;a<(FFTSIZE_512*2);a++) // need to change the lengths here for 1024 FFT
							{data_to_send_UART_512[a] = *chptr;*chptr++;}
						}
						if (ii==1)
						{
							// convert float array to byte array (averagePSD float array -> data_to_send_UART byte array
							chptr = (uint8_t *) &standard_dev_storage_512;
							for (a=0;a<(FFTSIZE_512*2);a++) // need to change the lengths here for 1024 FFT
							{data_to_send_UART_512[a] = *chptr;*chptr++;}
						}


						for (int y=0;y<number_of_SD_chunks_512;y++)
						{
							for (int j=0;j<512;j++)
							{
								SD_write_buff[j]=data_to_send_UART_512[j+SD_read_write_buff_increment[y]];
							}

							// sending data to SD card

							writestatus=0;

							spi_control_init(); // Initialization of SD card.

							SD_Card_Power_On();

							while (!(writestatus==12))
							{
								SD_init_return_status=0;

								while(!(SD_init_return_status==5))
								{
									SD_init_return_status = spi_SD_init(LPC_SSP1); // SPEED CLOCK RATE UP?

									if (SD_init_return_status==5)
									{
										//printf("SD Card Initialization Complete \n");
										//LPC_GPIO_PORT->CLR[5] |= (1UL << 9); // red
										break;
									}

									if (!(SD_init_return_status==5))
									{
										SD_Card_Power_Off();
										TIM_Waitus(50);
										SD_Card_Power_On();
										//LPC_GPIO_PORT->SET[5] |= (1UL << 9); // red
									}
									if (i==5000)
									{
										//printf("SD Card Not Initialized \n");
										SD_init_return_status=5; // break while
									}
									i++;
								}
								writestatus=SD_writeSingleBlock(address_SD_card_write,SD_write_buff,&token,LPC_SSP1);

								write_counter_512++;

								if (write_counter_512==3)
								{
									break;
								}

							}
							write_counter_512=0;

							/***
							writestatus=SD_writeSingleBlock(address_SD_card_write,SD_write_buff,&token,LPC_SSP1);

							if (writestatus==9)
							{

								SD_Card_Power_Off();
								TIM_Waitus(50);
								SD_Card_Power_On();
								SD_init_return_status=0;

								while(!(SD_init_return_status==5))
									{
									SD_init_return_status = spi_SD_init(LPC_SSP1);

									if (SD_init_return_status==5)
									{
										break;
									}

									if (!(SD_init_return_status==5))
									{
										SD_Card_Power_Off();

										SD_Card_Power_On();
									}
									if (i==5000)
									{
										SD_init_return_status=5; // break while
									}

									i++;
								}

							}
							***/

							address_SD_card_write++;

							LPC_GPIO_PORT->CLR[3] |= (1UL << 7);
						}
					}
				}


				//reading from card and printing to UART
				if (address_SD_card_write==SD_total_addresses)
					{

					for(int flight=0;flight<4;flight++)
					{
						LPC_GPIO_PORT->SET[3] |= (1UL << 4); // LED high (on) blue
						TIM_Waitms(20);
						LPC_GPIO_PORT->CLR[3] |= (1UL << 4); // LED high (on) blue
						TIM_Waitms(20);
						LPC_GPIO_PORT->SET[5] |= (1UL << 9); // red
						TIM_Waitms(20);
						LPC_GPIO_PORT->CLR[5] |= (1UL << 9); // red
						TIM_Waitms(20);
					}

					address_SD_card_write=1;
					reading_flag=1;
				}

				if (reading_flag==1)
				{

					Opamps_Off();


					while(address_SD_card_write<SD_total_addresses)
						{
						for (int y=0;y<number_of_SD_chunks_512;y++) // This needs to have a 512 version I think...
						{
							LPC_GPIO_PORT->SET[5] |= (1UL << 9); // red
							SD_readSingleBlock(address_SD_card_write,SD_read_buff,&token,LPC_SSP1);
							address_SD_card_write++;
							LPC_GPIO_PORT->CLR[5] |= (1UL << 9); // red
							for (int j=0;j<512;j++)
							{
								data_to_send_UART_512[j+SD_read_write_buff_increment[y]]=SD_read_buff[j];
							}

						}



						LPC_GPIO_PORT->SET[3] |= (1UL << 4); // LED high (on) blue
						I2C_Cmd(I2C_PORT, ENABLE);

						while(!(I2C_receive_byte[0]==16))
						{
							I2C_SlaveTransferData(I2C_PORT, &I2C_S_SETUP_Type, 0);
						}

						I2C_receive_byte[0]=0; // always have this after the command byte to reset command

						I2C_Cmd(I2C_PORT, DISABLE);

						LPC_GPIO_PORT->CLR[3] |= (1UL << 4); // LED high (on) blue




						/*** HERE
						// For testing the code via UART output

						LPC_GPIO_PORT->SET[3] |= (1UL << 4); // LED high (on) blue

						UART_TxCmd(LPC_USART2,ENABLE);

						// send start bytes
						for (int v=0;v<5;v++)
						{UART_SendByte(LPC_USART2,start_bytes_PSD[v]);}

						// send average PSD and SD (separately)
						for (int v=0;v<FFTSIZE_512*2;v++)
						{UART_SendByte(LPC_USART2,data_to_send_UART_512[v]);}

						UART_TxCmd(LPC_USART2,DISABLE);

						LPC_GPIO_PORT->CLR[3] |= (1UL << 4); // LED high (on) blue

						TIM_Waitms(50);
						***/ // TO HERE

					}

				}

				if (reading_flag==1)
				{
					address_SD_card_write=1;
					reading_flag=0;
					mstick=0;
					time_counter=0;
					finish_flag=1;
				}

				// zero averagePSD array
				for (int v=0;v<FFTSIZE_512/2;v++)
				{averagePSD_512[v] = averagePSD_512[v] * 0;}

				// zero SD^2 array
				for (int v=0;v<FFTSIZE_512/2;v++)
				{standard_dev_summation_squared_512[v] = standard_dev_summation_squared_512[v] * 0;}

				// zero SD_storage array
				for (int v=0;v<FFTSIZE_512/2;v++)
				{standard_dev_storage_512[v] = standard_dev_storage_512[v] * 0;}


			}
		}
	}
	finish_flag=0;
}


void Debris(int minutes_run_time_debris)
{

	// we still need to fix the calibration issue in the beginning!

	for (i=0;i<4;i++)
	{
		LPC_GPIO_PORT->SET[3] |= (1UL << 4); // LED high (on) blue
		TIM_Waitms(200);
		LPC_GPIO_PORT->CLR[3] |= (1UL << 4); // LED high (on) blue
		TIM_Waitms(200);
		LPC_GPIO_PORT->SET[5] |= (1UL << 9); // red
		TIM_Waitms(200);
		LPC_GPIO_PORT->CLR[5] |= (1UL << 9); // red
		TIM_Waitms(200);
	}

	i=0;


	I2C_S_SETUP_Type I2C_S_SETUP_Type;
	I2C_S_SETUP_Type.tx_data=data_to_send_UART_debris;
	I2C_S_SETUP_Type.tx_length=FFTSIZE_512; // only need 512 bytes per transfer.
	I2C_S_SETUP_Type.rx_data=I2C_receive_byte;
	I2C_S_SETUP_Type.rx_length=2;


	ADC_DiffOrSingle=1;

	// capture VADC settings
	capture_cfg_t cfg;
	cfg.numEnabledVADC = 0x01;
	cfg.numEnabledSGPIO = 0;
	cfg.sampleRate = 50000;// can't be less than 20kHz
	cfg.vadc.enabledChannels = (0x1 << 1);
	cfg.vadc.enabledTriggers = (0x0 << 0);
	cfg.vadc.voltPerDiv = (0 << 0);
	cfg.vadc.noiseReduction = (0 << 0);
	cfg.vadc.couplings = (1 << 0);
	cfg.postFill = 0x264; // ... 10011000100 for 16 samples and 100 percent buffer filled <- SET TO 50%??
	cfg.vadc.triggerSetup = (0x0 << 14);

	capture_Configure(&cfg, sizeof(cfg));

	//setting bytes to 0

	memset(0x20003ffe,0,2);
	memset(0x20007ffe,0,2);
	memset(0x2000bffe,0,2);
	memset(0x2000fffe,0,2);




	if (minutes_run_time_debris==0)
	{
		minutes_run_time_debris=60000;// 1 min
		// 10 minutes // formula is 4 per second so addresses = 4 * 60 * minutes + 1 (+1 is because the addresses start at 1).
	}
	else if (!(minutes_run_time_debris==0))
	{
		minutes_run_time_debris=(minutes_run_time_debris*18)*60000; // between 18 - 144 minutes (the * 60000 turns it into ms for while loop below)
		//SD_total_addresses=minutes_run_time_func_512*4320+1; // this function writes 4 addresses a second (240 a minute) but starts at 1 so we need to convert minutes into addresses
		// using this line. Also the value we get from the I2C is /18 less than the actual number of minutes we want so we need to multiply by 4 again
	}

	//minutes_run_time_debris=60000; // 60 seconds.

	mstick=0; // reset timer

	capture_Arm(); // start sample capture

	while(minutes_run_time_debris > mstick)
	{

		i=0;

		for (i=0;i<4;i++)
		{

			Opamps_On();

			for (j=0;j<64;j++)
			{
				storage_debris_array[j]=0;
				storage_time_debris_array[j]=0;
			}



			if (Read_Start_Next_Buff_Flag==1)
			{
				Read_Start_Next_Buff_Counter=6-Read_Start_Next_Buff_Counter;

				for (j=0;j<Read_Start_Next_Buff_Counter;j++)
				{
					storage_debris_array[j]=1;
				}

				Read_Start_Next_Buff_Counter=0;
				Read_Start_Next_Buff_Flag=0;

			}



			// random sample storage every minute
			if ((Random_Sample_Counter*60000)<mstick)
			{
				b=(rand() % 64);
				storage_debris_array[b]=1;
				//storage_ranking_debris_array[array_position]=(-99.9); // code for a random sample
				storage_time_debris_array[array_position]=mstick;
				Random_Sample_Counter++;
			}


			write_status_flag=0;
			val=0;

			if (i==0)
			{
				while(val==0)
				{
					//LPC_GPIO_PORT->SET[3] |= (1UL << 7);
					int16_t *pointer = 0x20003ffe;
					val =  *pointer;
				}
				//LPC_GPIO_PORT->CLR[3] |= (1UL << 7);
			}

			if (i==1)
			{
				while(val==0)
				{
					//LPC_GPIO_PORT->SET[3] |= (1UL << 7);
					int16_t *pointer = 0x20007ffe;
					val =  *pointer;
				}
				//LPC_GPIO_PORT->CLR[3] |= (1UL << 7);
			}

			if (i==2)
			{
				while(val==0)
				{
					//LPC_GPIO_PORT->SET[3] |= (1UL << 7);
					int16_t *pointer = 0x2000bffe;
					val =  *pointer;
				}
				//LPC_GPIO_PORT->CLR[3] |= (1UL << 7);
			}

			if (i==3)
			{
				while(val==0)
				{
					//LPC_GPIO_PORT->SET[3] |= (1UL << 7);
					int16_t *pointer = 0x2000fffe;
					val =  *pointer;
				}
				//LPC_GPIO_PORT->CLR[3] |= (1UL << 7);
			}


			for (j=0;j<(total_bytes_sampled/4);j+=2)
			{
				int16_t *pointer = (0x20000000 + buffer_size_dust[i] + j); /* Reading the
				integer value from the address pointed by ptr and storing it to the array "storage" (two lines down)*/
				val =  *pointer; // converting from int16_t to float
				storage_debris[j/2] = (val-6144)*0.0001953125;// converting from bit to voltage.
			}

			//LPC_GPIO_PORT->CLR[3] |= (1UL << 4); // LED high (off)


			// centering signal around 0
			// What we are wanting to do is find out what the DC offset is exactly
			//and subtract that value from the total above. This way we would not falsely
			//calibrate the 0 point if there is a lot of higher energy impacts
			// this calibration can be done above in line 1064.
			// so maybe the following 3 lines wont be necessary.


			LPC_GPIO_PORT->CLR[3] |= (1UL << 4); // LED high (off)

			// build array of 20 standard deviations and means
			arm_mean_f32(storage_debris,(total_bytes_sampled/8),&storage_average);
			arm_std_f32(storage_debris,(total_bytes_sampled/8),&Standard_Dev_Debris);
			MEAN_Buffer_Debris[Buffer_Counter_Debris]=storage_average;
			STDEV_Buffer_Debris[Buffer_Counter_Debris]=Standard_Dev_Debris;
			Buffer_Counter_Debris++;

			if (Buffer_Counter_Debris>=21)
			{
				//qsort(STDEV_Buffer_Debris, sizeof(STDEV_Buffer_Debris), sizeof(float), floatcomp2);
				Array_sort(STDEV_Buffer_Debris,21);
				median_Standard_Dev_Debris=STDEV_Buffer_Debris[10];

				//qsort(MEAN_Buffer_Debris, sizeof(MEAN_Buffer_Debris), sizeof(float), floatcomp2);
				Array_sort(MEAN_Buffer_Debris,21);
				median_Mean_Debris=MEAN_Buffer_Debris[10];

				//printf("%f \n",median_Mean_Debris);

				Buffer_Counter_Debris=0;

				if ((fabs(median_Mean_Debris)>0 && fabs(median_Standard_Dev_Debris)>0) && Calibrated_Debris==0)
				{
					Calibrated_Debris=1;
				}
			}

			//for (t=0;t<(total_bytes_sampled/8);t++)
			//{storage_debris[t] = storage_debris[t]-median_Mean_Debris;}


			if (Calibrated_Debris==1)
			{

				zeroCrossings=0;

				for (t=0;t<((total_bytes_sampled/8)-1);t++)
				{
					if ((storage_debris[t] >= median_Mean_Debris) && (storage_debris[t + 1]) < median_Mean_Debris)
					{zeroCrossings++;}
					if ((storage_debris[t] < median_Mean_Debris) && (storage_debris[t + 1] >= median_Mean_Debris))
					{zeroCrossings++;}
				}



				zero_crossing_frequency=(float)zeroCrossings/(float)8192; // kind of like a frequency but it is zerocrossings/sample
				// this is used to determine if a voltage spike is really a particle impact or just a noise spike.
				// If the voltage spike remains positive (or negative) for greater than 2-3x the average frequency then
				// it should be saved and sent to ground. This kind of acts as a high frequency noise filter.


				ZEROCROSS_Buffer_Debris[ZEROCROSS_Buffer_Counter_Debris]=zero_crossing_frequency;
				ZEROCROSS_Buffer_Counter_Debris++;

				if (ZEROCROSS_Buffer_Counter_Debris>=21)
				{
					//qsort(ZEROCROSS_Buffer_Debris, sizeof(ZEROCROSS_Buffer_Debris), sizeof(float), floatcomp2);
					Array_sort(ZEROCROSS_Buffer_Debris,21);
					median_Zero_Crossings_Debris=ZEROCROSS_Buffer_Debris[10];
					ZEROCROSS_Buffer_Counter_Debris=0;


					if ((fabs(median_Zero_Crossings_Debris)>0) && Zero_Crossings_Calibrated==0)
					{
						Zero_Crossings_Calibrated=1;

						//LPC_GPIO_PORT->SET[3] |= (1UL << 4); // LED high (on) blue
						//TIM_Waitms(2);
						//LPC_GPIO_PORT->CLR[3] |= (1UL << 4); // LED high (on) blue
						//TIM_Waitms(2);
						//LPC_GPIO_PORT->SET[5] |= (1UL << 9); // red
						//TIM_Waitms(2);
						//LPC_GPIO_PORT->CLR[5] |= (1UL << 9); // red
						//TIM_Waitms(2);

					}

				}

				if (Zero_Crossings_Calibrated==1)
				{

					for (t=0;t<(total_bytes_sampled/8);t++)
					{
						//LPC_GPIO_PORT->CLR[3] |= (1UL << 4); // LED high (off)
						//storage_average=fabs(storage_debris[t]);
						//printf("%f \n", storage_average);

						zeroCrossings2=0;
						peak_value=0;

						//for (b=0;b<50;b++) // need to calculate if the sample chunk has a lower than average zero crossing frequency...
						//{
					//		if ((storage_debris[t] >= median_Mean_Debris) && (storage_debris[t + 1]) < median_Mean_Debris)
					//		{zeroCrossings2++;}
					//		if ((storage_debris[t] < median_Mean_Debris) && (storage_debris[t + 1] >= median_Mean_Debris))
					//		{zeroCrossings2++;}
					//		t++; // I think it is fine to move over these numbers in main t variable loop.
					//		if(t>8190)
					//		{
					//			break;
					//		}
					//	}


						if (storage_debris[t]>(median_Mean_Debris+(median_Standard_Dev_Debris*4)))
						{
							while (storage_debris[t]>(median_Mean_Debris+(median_Standard_Dev_Debris*2)))
							{
								if (storage_debris[t]>peak_value)
								{
									peak_value=storage_debris[t];
								}
								zeroCrossings2++;
								t++;
								if (t>8191)
								{
									break;
								}
							}
							peak_value=peak_value-median_Mean_Debris;

						}
						else if (storage_debris[t]<(median_Mean_Debris-(median_Standard_Dev_Debris*4)))
						{
							while (storage_debris[t]<(median_Mean_Debris-(median_Standard_Dev_Debris*2)))
							{
								if (storage_debris[t]<peak_value)
								{
									peak_value=storage_debris[t];
								}
								zeroCrossings2++;
								t++;
								if (t>8191)
								{
									break;
								}
							}
							peak_value=median_Mean_Debris-peak_value; // should probably send the median_Mean_Debris value as well...
						}

						//zero_crossing_frequency2=(float)zeroCrossings2/b;// finding chunk average zero crossings rate
						if (zeroCrossings2>0)
						{
							zero_crossing_frequency2=1/zeroCrossings2; // should this be 2/zeroCrossings2?
						}
						else
						{
							zero_crossing_frequency2=1;
						}
						 // zeroCrossings2 is now the number of samples before a zero crossing.

						if(zero_crossing_frequency2*3<median_Zero_Crossings_Debris) // might need to divide zero_crossing_frequency by 1.2 or so...
						{

							LPC_GPIO_PORT->SET[3] |= (1UL << 4); // LED high (on)
							t=t-zeroCrossings2;
							// look for amplitude over a certain level. Should this be some level dependent on some average maximums?
							// Then say if there is some decrease
							// LPC_GPIO_PORT->SET[3] |= (1UL << 7); // red
							array_position = floor(t/128); // getting the array position for storage debris array

							//quality_factor=(peak_value)+((median_Zero_Crossings_Debris/zero_crossing_frequency2)/10); // max peak_value will be around 0.4. Now the smaller number for the zero_crossing_frequency2 the better.

							if (array_position <= 57)
							{
								storage_time_debris_array[array_position]=mstick;

								for (y=0;y<6;y++)
								{
									storage_debris_array[array_position]=1;
									array_position++;
								}
								//storage_ranking_debris_array[array_position]=quality_factor;

								t=array_position*128;

							}

							else if (array_position > 57)
							{

								//storage_ranking_debris_array[array_position]=quality_factor;
								storage_time_debris_array[array_position]=mstick;
								Read_Start_Next_Buff_Flag=1;


								while(array_position<64)
								{
									storage_debris_array[array_position]=1;
									array_position++;
									Read_Start_Next_Buff_Counter++;
								}
								break;
							}
						}
					}

					LPC_GPIO_PORT->CLR[3] |= (1UL << 4); // LED high (off)

					for (y=0;y<64;y++)
					{
						Debris_Buffer_Sum+=storage_debris_array[y];
					}

					if (Debris_Buffer_Sum>0)
					{

						//Opamps_Off();

						// so maybe here we need to count the Debris_Bufer_Sum variable and use it to have a few conditions...
						// if the Sum is < 20 then just save everything
						// if > 20 then we need to employ the quality factor to the samples to work out which 18 to store...
						// or simply put a sample counter variable that breaks the storage for loops when > 18.
						for (y=0;y<64;y++)
						{

							if (storage_debris_array[y]==1)
							{
								// take those 128 floats and store them in SD card.


								LPC_GPIO_PORT->SET[0] |= (1UL << 8);
								LPC_GPIO_PORT->SET[3] |= (1UL << 4); // LED high (on) blues
								//TIM_Waitms(1);
								//TIM_Waitus(10);



								if (storage_time_debris_array[y]!=0)
								{
									storage_debris[y*128]=storage_time_debris_array[y];
								}

								chptr = (uint8_t *) &storage_debris;
								chptr = chptr+((y)*512); // must add offset in bytes not floats!
								for (int a=0;a<512;a++) // this is a 2.56 ms chunk (each sample is 20e-6) and there are 4 of them per reading of interest
								{data_to_send_UART_debris[a] = *chptr;*chptr++;}


								SD_Card_Power_Off();

								spi_control_init(); // Initialization of SD card.

								SD_Card_Power_On();

								SD_init_return_status=0;

								while(!(SD_init_return_status==5))
								{
									SD_init_return_status = spi_SD_init(LPC_SSP1);

									if (SD_init_return_status==5)
									{
										//printf("SD Card Initialization Complete \n");
										//LPC_GPIO_PORT->CLR[5] |= (1UL << 9); // red
										break;
									}

									if (!(SD_init_return_status==5))
									{
										SD_Card_Power_Off();
										TIM_Waitus(50);
										SD_Card_Power_On();
										//LPC_GPIO_PORT->SET[5] |= (1UL << 9); // red
									}
									if (i==5000)
									{
										//printf("SD Card Not Initialized \n");
										SD_init_return_status=5; // break while
									}
									i++;
								}


								//LPC_GPIO_PORT->CLR[0] |= (1UL << 8);
								LPC_GPIO_PORT->CLR[3] |= (1UL << 4); // LED low (off) blue

								writestatus=SD_writeSingleBlock(address_SD_card_write,data_to_send_UART_debris,&token,LPC_SSP1);

								if (writestatus==9)
								{
									LPC_GPIO_PORT->SET[5] |= (1UL << 9); // green on debris or red on EDDI
									SD_Card_Power_Off();
									TIM_Waitus(200);
									SD_Card_Power_On();
									//SD_init_return_status=0;
									//printf("Write error \n");
									address_SD_card_write--;
									y--;
									LPC_GPIO_PORT->CLR[5] |= (1UL << 9); // green on debris or red on EDDI
								}

								address_SD_card_write++;

/***

								//sending time domain for amplifier testing
								chptr = (uint8_t *) &storage_debris;
								chptr = chptr+((y)*128);
								for (int a=0;a<512;a++) // this is a 10 ms chunk
								{data_to_send_UART_debris[a] = *chptr;*chptr++;}

								UART_TxCmd(LPC_USART2,ENABLE);

								// send start bytes
								for (int v=0;v<5;v++)
								{UART_SendByte(LPC_USART2,start_bytes_PSD[v]);}

								// time domain signal
								for (int v=0;v<512;v++)
								{UART_SendByte(LPC_USART2,data_to_send_UART_debris[v]);}

								UART_TxCmd(LPC_USART2,DISABLE);
****/




								// convert float array to byte array
								//chptr = (uint8_t *) &storage_debris+(y*128);
								//for (a=0;a<512;a++) // need to change the lengths here for 1024 FFT
								//{SD_write_buff[a] = *chptr;*chptr++;}

								//writestatus=SD_writeSingleBlock(address_SD_card_write,SD_write_buff,&token,LPC_SSP1);

							}
						}
					}

					Debris_Buffer_Sum=0;
				}
			}


			if (i==0)
			{
				memset(0x20003ffe,0,2);
			}

			if (i==1)
			{
				memset(0x20007ffe,0,2);
			}

			if (i==2)
			{
				memset(0x2000bffe,0,2);
			}

			if (i==3)
			{
				memset(0x2000fffe,0,2);
			}
		}
	}

	Calibrated_Debris=0;

	// here we print the SD card to UART and eventually I2C.
	SD_total_addresses=address_SD_card_write;
	address_SD_card_write=1;


	//chptr = (uint8_t *) &SD_total_addresses;
	//for (a=0;a<2;a++)
	//{data_to_send_UART_debris_addresses[a] = *chptr;*chptr++;}



	// I2C_S_SETUP_Type I2C_S_SETUP_Type; // THIS NEEDS REPAIRING BEFORE DEBUGGING
	//I2C_S_SETUP_Type.tx_data=data_to_send_UART_debris;
	//I2C_S_SETUP_Type.tx_length=FFTSIZE_512; // only need 512 bytes per transfer.
	//I2C_S_SETUP_Type.rx_data=I2C_receive_byte;
	//I2C_S_SETUP_Type.rx_length=2;

	//I2C_S_SETUP_Type I2C_S_SETUP_Type;
	//I2C_S_SETUP_Type.tx_data=data_to_send_UART_debris_addresses;
	//I2C_S_SETUP_Type.tx_length=2; //this has to be sent to the OBC
	//I2C_S_SETUP_Type.rx_data=I2C_receive_byte;
	//I2C_S_SETUP_Type.rx_length=2; // maybe need to have this in

	I2C_OWNSLAVEADDR_CFG_Type Slave_Add;
	//Slave_Add.GeneralCallState=ENABLE;
	Slave_Add.SlaveAddrChannel=0;
	//Slave_Add.SlaveAddrMaskValue
	Slave_Add.SlaveAddr_7bit=0x05;

	//Initialize I2C
	I2C_Init(I2C_PORT, 400000);
	I2C_Cmd(I2C_PORT, ENABLE);
	I2C_SetOwnSlaveAddr(I2C_PORT, &Slave_Add);



	//LPC_GPIO_PORT->SET[5] |= (1UL << 9); // LED high (on) red

	//while(!(I2C_receive_byte[0]==31)) // Here we wait for a 31 command to then send the addresses.
	//{
	//	I2C_SlaveTransferData(I2C_PORT, &I2C_S_SETUP_Type, 0);
	//}
	//I2C_receive_byte[0]=0; // always have this after the command byte to reset command
	//LPC_GPIO_PORT->CLR[5] |= (1UL << 9); // LED high (on) red


	//I2C_S_SETUP_Type I2C_S_SETUP_Type;
	//I2C_S_SETUP_Type.tx_data=data_to_send_UART_debris;
	//I2C_S_SETUP_Type.tx_length=512; //this has to be sent to the OBC
	//I2C_S_SETUP_Type.rx_data=I2C_receive_byte;
	//I2C_S_SETUP_Type.rx_length=2;


	debris_bytes_number_flag=0;

	while (address_SD_card_write<SD_total_addresses)
	{

		LPC_GPIO_PORT->SET[3] |= (1UL << 4); // LED high (on) blue

		if (debris_bytes_number_flag==0) // this sends the amount of bytes
		{
			chptr = (uint8_t *) &SD_total_addresses;

			for (a=0;a<512;a++)
			{
				if (a<2)
				{
					data_to_send_UART_debris[a] = *chptr;*chptr++;
				}
				else
				{
					data_to_send_UART_debris[a] = 0;
				}

			}

			while(!(I2C_receive_byte[0]==16))
			{
				I2C_SlaveTransferData(I2C_PORT, &I2C_S_SETUP_Type, 0);
			}
			I2C_receive_byte[0]=0; // always have this after the command byte to reset command

			debris_bytes_number_flag=1;

		}


		SD_readSingleBlock(address_SD_card_write,data_to_send_UART_debris,&token,LPC_SSP1);

		address_SD_card_write++;

		//LPC_GPIO_PORT->SET[3] |= (1UL << 4); // LED high (on) blue

		I2C_Cmd(I2C_PORT, ENABLE);


		while(!(I2C_receive_byte[0]==16))
		{
			I2C_SlaveTransferData(I2C_PORT, &I2C_S_SETUP_Type, 0);
		}
		I2C_receive_byte[0]=0; // always have this after the command byte to reset command

		I2C_Cmd(I2C_PORT, DISABLE);

		LPC_GPIO_PORT->CLR[3] |= (1UL << 4); // LED high (on) blue


		/*****
		UART_TxCmd(LPC_USART2,ENABLE);

		// send start bytes
		for (int v=0;v<5;v++)
		{UART_SendByte(LPC_USART2,start_bytes_PSD[v]);}

		LPC_GPIO_PORT->CLR[3] |= (1UL << 4); // LED high (on) blue

		// time domain signal
		for (int v=0;v<512;v++)
		{UART_SendByte(LPC_USART2,data_to_send_UART_debris[v]);}

		UART_TxCmd(LPC_USART2,DISABLE);

		TIM_Waitms(100);
		*****/

	}
}


void FFT_30_Sec_Av(int minutes_run_time_func_1024, uint16_t averages_1024)
{


	if (minutes_run_time_func_1024==0)
	{
		SD_total_addresses=241; // 30 seconds
		//SD_total_addresses=4801; 10 minutes
		//SD_total_addresses=57; 14 x 512 buffers
	}
	else
	{
		SD_total_addresses=(minutes_run_time_func_1024*8640)+1; // this function writes 8 addresses a second (480 a minute) but starts at 1 so we need to convert minutes into addresses
		// using this line. Also the value we get from the I2C is /18 less than the actual number of minutes we want so we need to multiply by 4 again
		// to work out how many buffers transfered you -1 and divide by 4
	}

	ADC_DiffOrSingle=0; // 0 for differential

	// capture VADC settings
	capture_cfg_t cfg;
	cfg.numEnabledVADC = 0x01;
	cfg.numEnabledSGPIO = 0;
	cfg.sampleRate = 40000000;// can't be less than 20kHz
	cfg.vadc.enabledChannels = (0x1 << 1);
	cfg.vadc.enabledTriggers = (0x0 << 0);
	cfg.vadc.voltPerDiv = (0 << 0);
	cfg.vadc.noiseReduction = (0 << 0);
	cfg.vadc.couplings = (1 << 0);
	cfg.postFill = 0x264; // ... 10011000100 for 16 samples and 100 percent buffer filled <- SET TO 50%??
	cfg.vadc.triggerSetup = (0x0 << 14);

	capture_Configure(&cfg, sizeof(cfg));


	// This is the default FFTSIZE (1024)
	// values in here have to be FFTSIZE
	arm_rfft_fast_instance_f32 *S = malloc(sizeof(arm_rfft_fast_instance_f32));
	S->fftLenRFFT = FFTSIZE;
	S->pTwiddleRFFT    = (float32_t *) twiddleCoef_rfft_1024;

	// values in here have to be FFTSIZE/2 (except for fftLen)
	arm_cfft_instance_f32 *Sint = malloc(sizeof(arm_cfft_instance_f32));
	Sint = &(S->Sint);
	Sint->fftLen = FFTSIZE;
	Sint->pTwiddle     = (float32_t *) twiddleCoef_512;
	Sint->bitRevLength = ARMBITREVINDEXTABLE_512_TABLE_LENGTH;
	Sint->pBitRevTable = (uint16_t *)armBitRevIndexTable512;

	I2C_S_SETUP_Type I2C_S_SETUP_Type;
	I2C_S_SETUP_Type.tx_data=data_to_send_UART;
	I2C_S_SETUP_Type.tx_length=FFTSIZE*2; // this is 2048 bytes
	I2C_S_SETUP_Type.rx_data=I2C_receive_byte;
	I2C_S_SETUP_Type.rx_length=2;


	//no_averages=20; // as many as can be done in a second (this could be less if we want to give time for possible SD card write errors)
	no_averages=averages_1024;

	mstick=0; //reset timer -- should be last thing done before while() starts.

	while(finish_flag==0) // to undo this make it while(1) and take out the finish_flag=1 from the bottom of the script.
	{

		LPC_GPIO_PORT->SET[3] |= (1UL << 4); // LED high (on)
		Opamps_On(); //think about turning these back on later.

		b=0;
		q=0;
		bb=0;
		qq=0;

		while(b==q || q==bb || bb==qq)
		{
			b = (rand() % 15);
			q = (rand() % 15);
			bb = (rand() % 15);
			qq = (rand() % 15);

		} // for selecting 4 random chunks of data from a sample buffer


		int random_numbers[4] = {b,q,bb,qq};

		Buffer_Full = 0;
		capture_Arm(); // start sample capture
		while (Buffer_Full<21) // waiting for 21 DMA interrupts meaning the entire buffer is full
		{}
		capture_Disarm(); // stop sample capture


		Opamps_Off(); //think about turning these back on later.



		for (p=0;p<4;p++) //
		{

			for (j=0;j<(FFTSIZE*2);j+=2)
			{
				int16_t *pointer = (0x20000000 + buffer_size_1024[random_numbers[p]] + j); /* Reading the
				integer value from the address pointed by ptr and storing it to the array "storage" (two lines down)*/
				val =  *pointer; // converting from int16_t to float
				storage[j/2] = (val-6144)*0.0001953125;//((val-4096)-311)/7801.4; //(((val-4096)-348.8)/4620.3)-0.362; //(((val-4096) + 404.5) / 4656)-0.564; // converting from bit to voltage. 3691.5
			}


			//Hann windowing
			for (i=0; i < FFTSIZE; i++)
			{multiplier = 0.5 * (1 - cos(2*PI*i/(FFTSIZE-1)));storage[i] = multiplier * storage[i];} // double check this function with FFTSIZe

			//FFT
			arm_rfft_fast_f32(S,storage,FFT,0);
			// magnitude squared
			arm_cmplx_mag_squared_f32(FFT, PSD, FFTSIZE/2);

			// Summation for standard deviation calculation later on
			for(e=0;e<FFTSIZE/2;e++)
			{standard_dev_summation_squared[e] = standard_dev_summation_squared[e] + pow(PSD[e],2);}

			// dividing by no_averages and adding to averagePSD
			for (m=0;m<FFTSIZE/2;m++)
			{averagePSD[m] = averagePSD[m]+(PSD[m]/no_averages);}


			counter++;


			if (counter == no_averages)
			{

				time_storage=mstick;

				time_counter++;


				while ((mstick/1000)<(time_counter*30))
				{
					LPC_GPIO_PORT->SET[5] |= (1UL << 9); // red
				}

				LPC_GPIO_PORT->CLR[5] |= (1UL << 9); // red // green on debris

				LPC_GPIO_PORT->CLR[3] |= (1UL << 4); // LED high (off)

				// Calculate the SD
				for (c=0;c<FFTSIZE/2;c++)
				{standard_dev_storage[c] = sqrt((standard_dev_summation_squared[c]/no_averages)-(pow(averagePSD[c],2)));}

				standard_dev_storage[(FFTSIZE/2)-1]=time_storage;

				counter=0;


				if (address_SD_card_write<SD_total_addresses)
				{

					LPC_GPIO_PORT->SET[3] |= (1UL << 7);

					for (int ii=0;ii<2;ii++)
					{

						if (ii==0)
						{
							// convert float array to byte array (averagePSD float array -> data_to_send_UART byte array
							chptr = (uint8_t *) &averagePSD;
							for (a=0;a<(FFTSIZE*2);a++) // need to change the lengths here for 1024 FFT
							{data_to_send_UART[a] = *chptr;*chptr++;}

						}
						if (ii==1)
						{
							// convert float array to byte array (averagePSD float array -> data_to_send_UART byte array
							chptr = (uint8_t *) &standard_dev_storage;
							for (a=0;a<(FFTSIZE*2);a++) // need to change the lengths here for 1024 FFT
							{data_to_send_UART[a] = *chptr;*chptr++;}

						}

						for (int y=0;y<number_of_SD_chunks;y++)
						{
							for (int j=0;j<512;j++)
							{
								SD_write_buff[j]=data_to_send_UART[j+SD_read_write_buff_increment[y]];
							}


							// sending data to SD card

							writestatus=0;

							spi_control_init(); // Initialization of SD card.

							SD_Card_Power_On();

							while (!(writestatus==12))
							{
								SD_init_return_status=0;

								while(!(SD_init_return_status==5))
								{
									SD_init_return_status = spi_SD_init(LPC_SSP1); // SPEED CLOCK RATE UP?

									if (SD_init_return_status==5)
									{
										//printf("SD Card Initialization Complete \n");
										LPC_GPIO_PORT->CLR[5] |= (1UL << 9); // red
										break;
									}

									if (!(SD_init_return_status==5))
									{
										SD_Card_Power_Off();
										TIM_Waitus(50); // testing 100 us
										SD_Card_Power_On();
										LPC_GPIO_PORT->SET[5] |= (1UL << 9); // red
									}
									if (i==5000)
									{
										//printf("SD Card Not Initialized \n");
										SD_init_return_status=5; // break while
										LPC_GPIO_PORT->SET[5] |= (1UL << 9); // red
									}
									i++;
								}

								writestatus=SD_writeSingleBlock(address_SD_card_write,SD_write_buff,&token,LPC_SSP1);

								write_counter_512++;

								if (write_counter_512==3)
								{
									LPC_GPIO_PORT->SET[5] |= (1UL << 9); // red
									break; // try to write 10 times, and if still doesn't work, skip that data and move on.

								}

							}
							write_counter_512=0;

							/****

							writestatus=SD_writeSingleBlock(address_SD_card_write,SD_write_buff,&token,LPC_SSP1);

							if (writestatus==9)
							{

								SD_Card_Power_Off();
								SD_Card_Power_On();
								SD_init_return_status=0;

								while(!(SD_init_return_status==5))
								{
									SD_init_return_status = spi_SD_init(LPC_SSP1); // SPEED CLOCK RATE UP?

									if (SD_init_return_status==5)
									{
										//printf("SD Card Initialization Complete \n");
										break;
									}

									if (!(SD_init_return_status==5))
									{
										SD_Card_Power_Off();
										TIM_Waitus(50);
										SD_Card_Power_On();
									}
									if (i==5000)
									{
										SD_init_return_status=5; // break while
									}

									i++;
								}

							}

							****/

							address_SD_card_write++;

							LPC_GPIO_PORT->CLR[3] |= (1UL << 7);
						}
					}
				}


				//reading from card and printing to UART
				if (address_SD_card_write==SD_total_addresses)
				{

					for(int flight=0;flight<4;flight++)
					{
						LPC_GPIO_PORT->SET[3] |= (1UL << 4); // LED high (on) blue
						TIM_Waitms(20);
						LPC_GPIO_PORT->CLR[3] |= (1UL << 4); // LED high (on) blue
						TIM_Waitms(20);
						LPC_GPIO_PORT->SET[5] |= (1UL << 9); // red
						TIM_Waitms(20);
						LPC_GPIO_PORT->CLR[5] |= (1UL << 9); // red
						TIM_Waitms(20);
					}


					address_SD_card_write=1;
					reading_flag=1;
					//printf("Starting Read and UART Print \n");
				}

				if (reading_flag==1)
				{

					Opamps_Off();

					while(address_SD_card_write<SD_total_addresses)
					{
						for (int y=0;y<number_of_SD_chunks;y++)
							{
							LPC_GPIO_PORT->SET[5] |= (1UL << 9); // red
							SD_readSingleBlock(address_SD_card_write,SD_read_buff,&token,LPC_SSP1);
							address_SD_card_write++;
							LPC_GPIO_PORT->CLR[5] |= (1UL << 9); // red
							for (int j=0;j<512;j++)
							{
								data_to_send_UART[j+SD_read_write_buff_increment[y]]=SD_read_buff[j];
							}

						}


						LPC_GPIO_PORT->SET[3] |= (1UL << 4); // LED high (on) blue
						I2C_Cmd(I2C_PORT, ENABLE);

						while(!(I2C_receive_byte[0]==16))
						{
							I2C_SlaveTransferData(I2C_PORT, &I2C_S_SETUP_Type, 0);
						}
						I2C_receive_byte[0]=0; // always have this after the command byte to reset command

						I2C_Cmd(I2C_PORT, DISABLE);

						LPC_GPIO_PORT->CLR[3] |= (1UL << 4); // LED high (on) blue


						/*** HERE

						LPC_GPIO_PORT->SET[3] |= (1UL << 4); // LED high (on) blue

						UART_TxCmd(LPC_USART2,ENABLE);

						// send start bytes
						for (int v=0;v<5;v++)
						{UART_SendByte(LPC_USART2,start_bytes_PSD[v]);}

						// send average PSD and SD (separately)
						for (int v=0;v<FFTSIZE*2;v++)
						{UART_SendByte(LPC_USART2,data_to_send_UART[v]);}

						UART_TxCmd(LPC_USART2,DISABLE);

						LPC_GPIO_PORT->CLR[3] |= (1UL << 4); // LED high (on) blue

						TIM_Waitms(50);
						***/ //TO HERE
					}

				}

				if (reading_flag==1)
				{
					address_SD_card_write=1;
					reading_flag=0;
					mstick=0;
					time_counter=0;
					finish_flag=1;
				}



				// zero averagePSD array
				for (int v=0;v<FFTSIZE/2;v++)
				{averagePSD[v] = averagePSD[v] * 0;}

				// zero SD^2 array
				for (int v=0;v<FFTSIZE/2;v++)
				{standard_dev_summation_squared[v] = standard_dev_summation_squared[v] * 0;}

				// zero SD_storage array
				for (int v=0;v<FFTSIZE/2;v++)
				{standard_dev_storage[v] = standard_dev_storage[v] * 0;}

			}
		}
	}
	finish_flag=0;
}


void FFT_60_Sec_Av(int minutes_run_time_func_1024, uint16_t averages_1024)
{


	if (minutes_run_time_func_1024==0)
	{
		SD_total_addresses=241; // 30 seconds
		//SD_total_addresses=4801; 10 minutes
		//SD_total_addresses=57; 14 x 512 buffers
	}
	else
	{
		SD_total_addresses=(minutes_run_time_func_1024*8640)+1; // this function writes 8 addresses a second (480 a minute) but starts at 1 so we need to convert minutes into addresses
		// using this line. Also the value we get from the I2C is /18 less than the actual number of minutes we want so we need to multiply by 4 again
		// to work out how many buffers transfered you -1 and divide by 4
	}

	ADC_DiffOrSingle=0; // 0 for differential

	// capture VADC settings
	capture_cfg_t cfg;
	cfg.numEnabledVADC = 0x01;
	cfg.numEnabledSGPIO = 0;
	cfg.sampleRate = 40000000;// can't be less than 20kHz
	cfg.vadc.enabledChannels = (0x1 << 1);
	cfg.vadc.enabledTriggers = (0x0 << 0);
	cfg.vadc.voltPerDiv = (0 << 0);
	cfg.vadc.noiseReduction = (0 << 0);
	cfg.vadc.couplings = (1 << 0);
	cfg.postFill = 0x264; // ... 10011000100 for 16 samples and 100 percent buffer filled <- SET TO 50%??
	cfg.vadc.triggerSetup = (0x0 << 14);

	capture_Configure(&cfg, sizeof(cfg));


	// This is the default FFTSIZE (1024)
	// values in here have to be FFTSIZE
	arm_rfft_fast_instance_f32 *S = malloc(sizeof(arm_rfft_fast_instance_f32));
	S->fftLenRFFT = FFTSIZE;
	S->pTwiddleRFFT    = (float32_t *) twiddleCoef_rfft_1024;

	// values in here have to be FFTSIZE/2 (except for fftLen)
	arm_cfft_instance_f32 *Sint = malloc(sizeof(arm_cfft_instance_f32));
	Sint = &(S->Sint);
	Sint->fftLen = FFTSIZE;
	Sint->pTwiddle     = (float32_t *) twiddleCoef_512;
	Sint->bitRevLength = ARMBITREVINDEXTABLE_512_TABLE_LENGTH;
	Sint->pBitRevTable = (uint16_t *)armBitRevIndexTable512;

	I2C_S_SETUP_Type I2C_S_SETUP_Type;
	I2C_S_SETUP_Type.tx_data=data_to_send_UART;
	I2C_S_SETUP_Type.tx_length=FFTSIZE*2; // this is 2048 bytes
	I2C_S_SETUP_Type.rx_data=I2C_receive_byte;
	I2C_S_SETUP_Type.rx_length=2;


	//no_averages=20; // as many as can be done in a second (this could be less if we want to give time for possible SD card write errors)
	no_averages=averages_1024;

	mstick=0; //reset timer -- should be last thing done before while() starts.

	while(finish_flag==0) // to undo this make it while(1) and take out the finish_flag=1 from the bottom of the script.
	{

		LPC_GPIO_PORT->SET[3] |= (1UL << 4); // LED high (on)
		Opamps_On(); //think about turning these back on later.

		b=0;
		q=0;
		bb=0;
		qq=0;

		while(b==q || q==bb || bb==qq)
		{
			b = (rand() % 15);
			q = (rand() % 15);
			bb = (rand() % 15);
			qq = (rand() % 15);

		} // for selecting 4 random chunks of data from a sample buffer


		int random_numbers[4] = {b,q,bb,qq};

		Buffer_Full = 0;
		capture_Arm(); // start sample capture
		while (Buffer_Full<21) // waiting for 21 DMA interrupts meaning the entire buffer is full
		{}
		capture_Disarm(); // stop sample capture


		Opamps_Off(); //think about turning these back on later.



		for (p=0;p<4;p++) //
		{

			for (j=0;j<(FFTSIZE*2);j+=2)
			{
				int16_t *pointer = (0x20000000 + buffer_size_1024[random_numbers[p]] + j); /* Reading the
				integer value from the address pointed by ptr and storing it to the array "storage" (two lines down)*/
				val =  *pointer; // converting from int16_t to float
				storage[j/2] = (val-6144)*0.0001953125;//((val-4096)-311)/7801.4; //(((val-4096)-348.8)/4620.3)-0.362; //(((val-4096) + 404.5) / 4656)-0.564; // converting from bit to voltage. 3691.5
			}


			//Hann windowing
			for (i=0; i < FFTSIZE; i++)
			{multiplier = 0.5 * (1 - cos(2*PI*i/(FFTSIZE-1)));storage[i] = multiplier * storage[i];} // double check this function with FFTSIZe

			//FFT
			arm_rfft_fast_f32(S,storage,FFT,0);
			// magnitude squared
			arm_cmplx_mag_squared_f32(FFT, PSD, FFTSIZE/2);

			// Summation for standard deviation calculation later on
			for(e=0;e<FFTSIZE/2;e++)
			{standard_dev_summation_squared[e] = standard_dev_summation_squared[e] + pow(PSD[e],2);}

			// dividing by no_averages and adding to averagePSD
			for (m=0;m<FFTSIZE/2;m++)
			{averagePSD[m] = averagePSD[m]+(PSD[m]/no_averages);}


			counter++;


			if (counter == no_averages)
			{

				time_storage=mstick;

				time_counter++;


				while ((mstick/1000)<(time_counter*60))
				{
					LPC_GPIO_PORT->SET[5] |= (1UL << 9); // red
				}
				LPC_GPIO_PORT->CLR[5] |= (1UL << 9); // red // green on debris

				LPC_GPIO_PORT->CLR[3] |= (1UL << 4); // LED high (off)

				// Calculate the SD
				for (c=0;c<FFTSIZE/2;c++)
				{standard_dev_storage[c] = sqrt((standard_dev_summation_squared[c]/no_averages)-(pow(averagePSD[c],2)));}

				standard_dev_storage[(FFTSIZE/2)-1]=time_storage;

				counter=0;


				if (address_SD_card_write<SD_total_addresses)
				{

					LPC_GPIO_PORT->SET[3] |= (1UL << 7);

					for (int ii=0;ii<2;ii++)
					{

						if (ii==0)
						{
							// convert float array to byte array (averagePSD float array -> data_to_send_UART byte array
							chptr = (uint8_t *) &averagePSD;
							for (a=0;a<(FFTSIZE*2);a++) // need to change the lengths here for 1024 FFT
							{data_to_send_UART[a] = *chptr;*chptr++;}

						}
						if (ii==1)
						{
							// convert float array to byte array (averagePSD float array -> data_to_send_UART byte array
							chptr = (uint8_t *) &standard_dev_storage;
							for (a=0;a<(FFTSIZE*2);a++) // need to change the lengths here for 1024 FFT
							{data_to_send_UART[a] = *chptr;*chptr++;}

						}

						for (int y=0;y<number_of_SD_chunks;y++)
						{
							for (int j=0;j<512;j++)
							{
								SD_write_buff[j]=data_to_send_UART[j+SD_read_write_buff_increment[y]];
							}


							// sending data to SD card

							writestatus=0;

							spi_control_init(); // Initialization of SD card.

							SD_Card_Power_On();

							while (!(writestatus==12))
							{
								SD_init_return_status=0;

								while(!(SD_init_return_status==5))
								{
									SD_init_return_status = spi_SD_init(LPC_SSP1); // SPEED CLOCK RATE UP?

									if (SD_init_return_status==5)
									{
										//printf("SD Card Initialization Complete \n");
										LPC_GPIO_PORT->CLR[5] |= (1UL << 9); // red
										break;
									}

									if (!(SD_init_return_status==5))
									{
										SD_Card_Power_Off();
										TIM_Waitus(50); // testing 100 us
										SD_Card_Power_On();
										LPC_GPIO_PORT->SET[5] |= (1UL << 9); // red
									}
									if (i==5000)
									{
										//printf("SD Card Not Initialized \n");
										SD_init_return_status=5; // break while
										LPC_GPIO_PORT->SET[5] |= (1UL << 9); // red
									}
									i++;
								}

								writestatus=SD_writeSingleBlock(address_SD_card_write,SD_write_buff,&token,LPC_SSP1);

								write_counter_512++;

								if (write_counter_512==3)
								{
									LPC_GPIO_PORT->SET[5] |= (1UL << 9); // red
									break; // try to write 10 times, and if still doesn't work, skip that data and move on.

								}

							}
							write_counter_512=0;

							/****

							writestatus=SD_writeSingleBlock(address_SD_card_write,SD_write_buff,&token,LPC_SSP1);

							if (writestatus==9)
							{

								SD_Card_Power_Off();
								SD_Card_Power_On();
								SD_init_return_status=0;

								while(!(SD_init_return_status==5))
								{
									SD_init_return_status = spi_SD_init(LPC_SSP1); // SPEED CLOCK RATE UP?

									if (SD_init_return_status==5)
									{
										//printf("SD Card Initialization Complete \n");
										break;
									}

									if (!(SD_init_return_status==5))
									{
										SD_Card_Power_Off();
										TIM_Waitus(50);
										SD_Card_Power_On();
									}
									if (i==5000)
									{
										SD_init_return_status=5; // break while
									}

									i++;
								}

							}

							****/

							address_SD_card_write++;

							LPC_GPIO_PORT->CLR[3] |= (1UL << 7);
						}
					}
				}


				//reading from card and printing to UART
				if (address_SD_card_write==SD_total_addresses)
				{

					for(int flight=0;flight<4;flight++)
					{
						LPC_GPIO_PORT->SET[3] |= (1UL << 4); // LED high (on) blue
						TIM_Waitms(20);
						LPC_GPIO_PORT->CLR[3] |= (1UL << 4); // LED high (on) blue
						TIM_Waitms(20);
						LPC_GPIO_PORT->SET[5] |= (1UL << 9); // red
						TIM_Waitms(20);
						LPC_GPIO_PORT->CLR[5] |= (1UL << 9); // red
						TIM_Waitms(20);
					}


					address_SD_card_write=1;
					reading_flag=1;
					//printf("Starting Read and UART Print \n");
				}

				if (reading_flag==1)
				{

					Opamps_Off();

					while(address_SD_card_write<SD_total_addresses)
					{
						for (int y=0;y<number_of_SD_chunks;y++)
							{
							LPC_GPIO_PORT->SET[5] |= (1UL << 9); // red
							SD_readSingleBlock(address_SD_card_write,SD_read_buff,&token,LPC_SSP1);
							address_SD_card_write++;
							LPC_GPIO_PORT->CLR[5] |= (1UL << 9); // red
							for (int j=0;j<512;j++)
							{
								data_to_send_UART[j+SD_read_write_buff_increment[y]]=SD_read_buff[j];
							}

						}


						LPC_GPIO_PORT->SET[3] |= (1UL << 4); // LED high (on) blue
						I2C_Cmd(I2C_PORT, ENABLE);

						while(!(I2C_receive_byte[0]==16))
						{
							I2C_SlaveTransferData(I2C_PORT, &I2C_S_SETUP_Type, 0);
						}
						I2C_receive_byte[0]=0; // always have this after the command byte to reset command

						I2C_Cmd(I2C_PORT, DISABLE);

						LPC_GPIO_PORT->CLR[3] |= (1UL << 4); // LED high (on) blue


						/*** HERE

						LPC_GPIO_PORT->SET[3] |= (1UL << 4); // LED high (on) blue

						UART_TxCmd(LPC_USART2,ENABLE);

						// send start bytes
						for (int v=0;v<5;v++)
						{UART_SendByte(LPC_USART2,start_bytes_PSD[v]);}

						// send average PSD and SD (separately)
						for (int v=0;v<FFTSIZE*2;v++)
						{UART_SendByte(LPC_USART2,data_to_send_UART[v]);}

						UART_TxCmd(LPC_USART2,DISABLE);

						LPC_GPIO_PORT->CLR[3] |= (1UL << 4); // LED high (on) blue

						TIM_Waitms(50);
						***/ //TO HERE
					}

				}

				if (reading_flag==1)
				{
					address_SD_card_write=1;
					reading_flag=0;
					mstick=0;
					time_counter=0;
					finish_flag=1;
				}



				// zero averagePSD array
				for (int v=0;v<FFTSIZE/2;v++)
				{averagePSD[v] = averagePSD[v] * 0;}

				// zero SD^2 array
				for (int v=0;v<FFTSIZE/2;v++)
				{standard_dev_summation_squared[v] = standard_dev_summation_squared[v] * 0;}

				// zero SD_storage array
				for (int v=0;v<FFTSIZE/2;v++)
				{standard_dev_storage[v] = standard_dev_storage[v] * 0;}

			}
		}
	}
	finish_flag=0;
}






/******************************************************************************
 * Main method
 *****************************************************************************/

/**************************************************************************//**
 *
 * @brief   Entry point.
 *
 *****************************************************************************/
int real_main (void)
{


	TIM_TIMERCFG_Type timerCfg;
	TIM_CAPTURECFG_Type timerCfg2;

	SystemInit();

	CGU_Improved_Init();

	RGU_SoftReset(RGU_SIG_ADC0);
	RGU_SoftReset(RGU_SIG_DAC);
	RGU_SoftReset(RGU_SIG_LCD);
	RGU_SoftReset(RGU_SIG_DMA);
	RGU_SoftReset(RGU_SIG_GPIO);
	RGU_SoftReset(RGU_SIG_TIMER0);
	RGU_SoftReset(RGU_SIG_I2C0);
	RGU_SoftReset(RGU_SIG_USB0);
	RGU_SoftReset(RGU_SIG_SGPIO);
	RGU_SoftReset(RGU_SIG_VADC);
	//RGU_SoftReset(RGU_SIG_SPIFI);  //important to not do when booting from SPIFI

	/* Initialize timer */
	TIM_ConfigStructInit(TIM_TIMER_MODE, &timerCfg);
	TIM_Init(LPC_TIMER0, TIM_TIMER_MODE, &timerCfg);

	TIM_ConfigCapture(LPC_TIMER0,&timerCfg2);

	pinConfig();
	priorityConfig();

	/* Request systicks every ms */
	SysTick_Config(SystemCoreClock/1000);

	setupCalibrationSignal();

	#if (ENABLE_LOGGING == OPT_ENABLED)
	debug_frmwrk_init();
	PrintGreeting();
	#endif


	// Initialisation of I2C variables // we need this here because we receive commands with it! its probably ok that the variables will change depending on the function
	// but should probably move this into the main loop.
	I2C_S_SETUP_Type I2C_S_SETUP_Type;
	I2C_S_SETUP_Type.tx_data=data_to_send_UART;
	I2C_S_SETUP_Type.tx_length=FFTSIZE*2; // for 1024 FFT
	I2C_S_SETUP_Type.rx_data=I2C_receive_byte;
	I2C_S_SETUP_Type.rx_length=2;


	I2C_OWNSLAVEADDR_CFG_Type Slave_Add;
	//Slave_Add.GeneralCallState=ENABLE;
	Slave_Add.SlaveAddrChannel=0;
	//Slave_Add.SlaveAddrMaskValue
	Slave_Add.SlaveAddr_7bit=0x05;

	/* Initialize I2C */
	I2C_Init(I2C_PORT, 400000);
	I2C_Cmd(I2C_PORT, ENABLE);
	I2C_SetOwnSlaveAddr(I2C_PORT, &Slave_Add);


	//TAKE THIS OUT IF SD CARD NO LONGER WORKS
	// use these lines if higher SD card transfer rate is needed - 100kb should be high enough for this application
	SSP_CFG_Type SD_Init2;
	// Set clock rate

	// Initialize SSP peripheral with parameter given in structure above
	//SSP_ConfigStructInit(&SD_Init2);
	//SD_Init2.ClockRate = 400000;
	SSP_Init(LPC_SSP1, &SD_Init2);


	if (SD_active==0)
	{
		spi_control_init(); // Initialization of SD card.
		SD_Card_Power_On();


		while(!(SD_init_return_status==5))
		{
			SD_init_return_status = spi_SD_init(LPC_SSP1); // SPEED CLOCK RATE UP?

			if (SD_init_return_status==5)
			{
				//printf("SD Card Initialization Complete \n");
				//LPC_GPIO_PORT->CLR[5] |= (1UL << 9); // red
				break;
			}

			if (!(SD_init_return_status==5))
			{
				SD_Card_Power_Off();
				TIM_Waitus(50);
				SD_Card_Power_On();
			}
			if (i==5000)
			{
				//printf("SD Card Not Initialized \n");
				//LPC_GPIO_PORT->SET[5] |= (1UL << 9); // red
				SD_init_return_status=5; // break while
			}

			i++;
		}
	}

	experiments_Run();

	/* Make sure calibration data is loaded (or at least set to defaults) */
	calibrate_Init();

	statemachine_Init();


	//UART settings // this can be removed for the flight version...
	UART_CFG_Type UART;
	UART.Baud_rate = 256000;
	UART.Parity = UART_PARITY_NONE;
	UART.Databits = UART_DATABIT_8;
	UART.Stopbits = UART_STOPBIT_2;
	UART.Clock_Speed = 0;

	/* Initialize UART */
	UART_Init(LPC_USART2,&UART);

	// DCINNEG <- search for this and make value = 1 for single ended and 0 for differential mode. (currently dif ended)

	while(1) // this is new permanent while loop. The first thing is to wait for an I2C command. Then proceed with the parameters from the command.
	{

		if (Testing_Mode==1) // Simply turns on op-amps
		{
			Opamps_On();
			gain=0;
			LMH6881_VGA_CONTROL(gain);
			FFT_512_SD_saving(0,20);
			while(1)
			{
				// do nothing

				LPC_GPIO_PORT->SET[3] |= (1UL << 4); // LED high (on) blue
				TIM_Waitms(200);
				LPC_GPIO_PORT->CLR[3] |= (1UL << 4); // LED high (on) blue
				TIM_Waitms(200);
				LPC_GPIO_PORT->SET[5] |= (1UL << 9); // red
				TIM_Waitms(200);
				LPC_GPIO_PORT->CLR[5] |= (1UL << 9); // red
				TIM_Waitms(200);

			}
		}

		if (Testing_Mode==2) // Runs continuous UART prints in 1024 mode.
		{
			Opamps_On();
			gain=0;
			LMH6881_VGA_CONTROL(gain);
			FFT_1024_UART_Print(7,20);
			while(1)
			{
				// do nothing
				LPC_GPIO_PORT->SET[3] |= (1UL << 4); // LED high (on) blue
				TIM_Waitms(200);
				LPC_GPIO_PORT->CLR[3] |= (1UL << 4); // LED high (on) blue
				TIM_Waitms(200);
				LPC_GPIO_PORT->SET[5] |= (1UL << 9); // red
				TIM_Waitms(200);
				LPC_GPIO_PORT->CLR[5] |= (1UL << 9); // red
				TIM_Waitms(200);

			}
		}




		LPC_GPIO_PORT->CLR[3] |= (1UL << 7);

		I2C_Cmd(I2C_PORT, ENABLE);

		while(I2C_receive_byte[0]==0)
		{
			I2C_SlaveTransferData(I2C_PORT, &I2C_S_SETUP_Type, 0);
		}

		I2C_Cmd(I2C_PORT, DISABLE);


		gain = (I2C_receive_byte[0] & 0X18);// middle two bits? still have to write this... it is written! 00, 01, 10, 11 are gains of... check in function!
		mode = (I2C_receive_byte[0] & 0XE0); // This will be the mode selected by I2C which will select the function to run below.
		minutes_run_time = (I2C_receive_byte[0] & 0x07); // this will be the variable where the 5 bytes from the I2C command are converted into minutes
		// and put into the functions below

		//printf("%d \n", I2C_receive_byte[0]);

		Opamps_On(); // This function also exists in FFT functions but not sure if LMH need to be on before the gain...
		LMH6881_VGA_CONTROL(gain); // gain is controlled with middle two bits. 00 is gain of 6 db, 01=16, 10=22, 11=26.
		I2C_receive_byte[0]=0;

		if (mode == 0) // Antenna Deployment
		{
			Antenna_Deployment();
		}

		if (mode == 32) // 512 Point FFT high power mode
		{
			FFT_512_SD_saving(minutes_run_time,40);
		}

		else if (mode==64) // 1024 Point FFT high power mode
		{

			FFT_1024_SD_saving(minutes_run_time,20);
		}

		else if (mode==96) // 512 Point FFT low power mode
		{
			FFT_512_SD_saving(minutes_run_time,4);
		}

		else if (mode==128) // 1024 Point FFT low power mode
		{
			FFT_1024_SD_saving(minutes_run_time,4);
		}

		else if (mode==160) // Debris Mode
		{
			Debris(minutes_run_time);
		}

		else if (mode==192) // FFT mode 1024 point with 30 seconds of averaging
		{
			FFT_30_Sec_Av(minutes_run_time,600);
		}

		else if (mode==224) // FFT mode 1024 point with 60 seconds of averaging
		{
			FFT_60_Sec_Av(minutes_run_time,1200);
		}


	}
}



